import React, { useState, useEffect } from 'react';
import {
    collection, query, orderBy, onSnapshot, getDoc, doc, updateDoc, serverTimestamp, arrayUnion, where, getDocs, increment, addDoc, setDoc
} from 'firebase/firestore';
import {
    Wallet, UploadCloud, History, CreditCard, Banknote, ChevronRight, CheckCircle, Printer, Download, Share2, Tag, X, Clock
} from 'lucide-react';
import { db, appId } from '../../config/firebase';
import { Button, Card, Badge } from '../ui/Elements';
import { Modal } from '../ui/Overlays';
import { fileToBase64 } from '../../utils/helpers';
import { MidtransMock } from './MidtransMock';

export default function PaymentHistory({ user, showToast }) {
    const [invoices, setInvoices] = useState([]);
    const [registrations, setRegistrations] = useState([]);
    const [activeInvoice, setActiveInvoice] = useState(null); // For Payment Gateway
    const [payConfig, setPayConfig] = useState({ gateway_active: 'manual', manual_banks: [] });
    const [uploadProof, setUploadProof] = useState(null);
    const [selectedBank, setSelectedBank] = useState(null);
    const [isInstallment, setIsInstallment] = useState(false);
    const [installmentTerms, setInstallmentTerms] = useState(2);
    const [settings, setSettings] = useState({});

    // Installment Payment State
    const [viewInstallment, setViewInstallment] = useState(null); // To view installment schedule
    const [activeTermPay, setActiveTermPay] = useState(null); // Which term is being paid { index, amount, ... }

    const [viewInvoice, setViewInvoice] = useState(null);
    const invoiceRef = React.useRef(null);

    // Voucher State
    const [voucherCode, setVoucherCode] = useState('');
    const [appliedVoucher, setAppliedVoucher] = useState(null);
    const [calculating, setCalculating] = useState(false);

    const handleDownloadPDF = async () => {
        try {
            const html2canvas = (await import('html2canvas')).default;
            const jsPDF = (await import('jspdf')).default;

            const element = invoiceRef.current;
            if (!element) return;

            const canvas = await html2canvas(element, { scale: 2 });
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('p', 'mm', 'a4'); // Invoice fits A4
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

            pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
            pdf.save(`Invoice_${viewInvoice?.invoice_number_formatted || viewInvoice?.id || 'Bayar'}.pdf`);
        } catch (error) {
            console.error('PDF Generation failed', error);
            alert('Gagal mendownload PDF.');
        }
    };

    const handleShare = async () => {
        const shareData = {
            title: 'Invoice Pembayaran Sekolah',
            text: `Invoice ${viewInvoice?.invoice_number_formatted ? '#' + viewInvoice.invoice_number_formatted : '#' + viewInvoice?.id} sebesar Rp ${viewInvoice?.amount?.toLocaleString()}`,
            url: window.location.href
        };
        if (navigator.share) {
            try { await navigator.share(shareData); } catch (e) { }
        } else {
            navigator.clipboard.writeText(`${shareData.title}\n${shareData.text}\n${shareData.url}`);
            alert('Info invoice disalin!');
        }
    };

    useEffect(() => {
        if (!user) return;
        const q = query(collection(db, 'artifacts', appId, 'users', user.uid, 'invoices'), orderBy('created_at', 'desc'));
        const unsub = onSnapshot(q, (snap) => setInvoices(snap.docs.map(d => ({ id: d.id, ...d.data() }))));

        // Fetch registrations to create invoice if needed
        const qReg = query(collection(db, 'artifacts', appId, 'users', user.uid, 'registrations'));
        const unsubReg = onSnapshot(qReg, (snap) => setRegistrations(snap.docs.map(d => ({ id: d.id, ...d.data() }))));

        const unsubConfig = onSnapshot(doc(db, 'artifacts', appId, 'public', 'data', 'payment_config', 'main'), (snap) => {
            if (snap.exists()) setPayConfig(snap.data());
        });
        getDoc(doc(db, 'artifacts', appId, 'public', 'settings')).then(s => s.exists() && setSettings(s.data()));
        return () => { unsub(); unsubConfig(); unsubReg(); };
    }, [user]);

    // Auto-generate Invoice for Lulus students
    useEffect(() => {
        const checkAndGenerateInvoices = async () => {
            if (!registrations.length) return;

            for (const reg of registrations) {
                // Check scholarship status to prevent invoice generation
                const isScholarship = reg.is_scholarship || (reg.path_name && (reg.path_name.toLowerCase().includes('prestasi') || reg.path_name.toLowerCase().includes('yatim')));

                // Check if Inden/Internal (Handled by AdminVerification already)
                const isIndenInternal = reg.is_indent || reg.is_internal || (reg.path_name && (reg.path_name.toLowerCase().includes('internal') || reg.path_name.toLowerCase().includes('indent')));

                // Modified: Only generate if status is Lulus AND Agreements are Verified AND NOT SCHOLARSHIP
                // We removed !isIndenInternal because Indent External (and non-scholarship Internal) MUST pay re-registration now.
                if ((reg.status === 'lulus' || reg.status === 'accepted') && reg.agreements_verified === true && !isScholarship) {

                    // Use deterministic ID to strictly prevent duplicates
                    const deterministicId = `rereg_${reg.id}`;
                    // Check if invoice exists (by ID or legacy check)
                    const exists = invoices.find(inv => inv.id === deterministicId || (inv.registration_id === reg.id && inv.description?.toLowerCase().includes('daftar ulang')));

                    if (!exists) {
                        try {
                            // double check with server to prevent overwrite on race condition
                            const newInvRef = doc(db, 'artifacts', appId, 'users', user.uid, 'invoices', deterministicId);
                            const finalCheck = await getDoc(newInvRef);
                            if (finalCheck.exists()) return;

                            let amount = 0;
                            // 1. Try Unit Cost
                            if (reg.unit_id) {
                                const uSnap = await getDoc(doc(db, 'artifacts', appId, 'public', 'data', 'units', reg.unit_id));
                                if (uSnap.exists()) {
                                    amount = parseInt(uSnap.data().cost_rereg || 0);
                                }
                            }
                            // 2. Fallback to Global
                            if (!amount && settings.reregistration_fee) {
                                amount = parseInt(settings.reregistration_fee);
                            }

                            if (amount > 0) {
                                // Use Deterministic ID
                                const invData = {
                                    id: deterministicId,
                                    registration_id: reg.id,
                                    student_name: reg.student_name,
                                    amount: amount,
                                    description: 'Biaya Daftar Ulang',
                                    status: 'pending',
                                    created_at: serverTimestamp(),
                                    due_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
                                    user_id: user.uid
                                };

                                await setDoc(newInvRef, invData);
                                // Mirror to public
                                await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'all_invoices', deterministicId), invData);
                                showToast('Tagihan Daftar Ulang berhasil dibuat.', 'success');
                            }
                        } catch (e) {
                            console.error("Auto invoice creation failed", e);
                        }
                    }
                }
            }
        };

        if (user && settings) {
            checkAndGenerateInvoices();
        }
    }, [registrations, invoices, settings, user]);

    const handlePay = async (inv) => {
        // Validation for Daftar Ulang (Must upload Agreement & MCU)
        if (inv.description?.toLowerCase().includes('daftar ulang') || inv.description?.toLowerCase().includes('re-registration')) {
            try {
                const regSnap = await getDoc(doc(db, 'artifacts', appId, 'users', user.uid, 'registrations', inv.registration_id));
                if (regSnap.exists()) {
                    const rData = regSnap.data();
                    const docs = rData.uploaded_docs || {};
                    const hasRokok = docs.agreement_rokok;
                    const hasLGBT = docs.agreement_lgbt;
                    const hasKriminal = docs.agreement_kriminal;
                    const hasMCU = docs.mcu_letter;

                    if (!hasRokok || !hasLGBT || !hasKriminal || !hasMCU) {
                        showToast('Harap upload 3 Surat Pernyataan & Surat Sehat MCU di menu Data Anak terlebih dahulu!', 'error');
                        return;
                    }
                }
            } catch (e) {
                console.error("Error checking docs", e);
            }
        }

        if (payConfig.gateway_active === 'midtrans') {
            setActiveInvoice(inv);
        } else {
            setActiveInvoice(inv); // Use modal for manual upload too
        }
    };

    const handleManualUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        try {
            const base64 = await fileToBase64(file);
            setUploadProof(base64);
        } catch (err) { showToast(err.message, 'error'); }
    };

    const handleApplyVoucher = async () => {
        if (!voucherCode) return;
        setCalculating(true);
        try {
            // Find voucher
            const q = query(collection(db, 'artifacts', appId, 'public', 'data', 'vouchers'), where('code', '==', voucherCode.toUpperCase().trim()), where('active', '==', true));
            const snap = await getDocs(q);

            if (snap.empty) throw new Error('Kode voucher tidak ditemukan atau tidak aktif.');

            const voucher = { id: snap.docs[0].id, ...snap.docs[0].data() };

            if (voucher.quota > 0 && (voucher.used || 0) >= voucher.quota) {
                throw new Error('Kuota voucher telah habis.');
            }

            // Check if eligible (only for 'Daftar Ulang' usually, based on user request "potongan pembayaran daftar ulang")
            // But let's allow for all for now, or check description
            if (!activeInvoice.description.toLowerCase().includes('daftar ulang')) {
                // Optional: Enforce this restriction? The user prompt said "untuk bisa digunakan potongan pembayaran daftar ulang"
                // Let's warn but maybe not hard block unless strict?
                // Ideally hard block.
                if (!activeInvoice.description.toLowerCase().includes('daftar ulang')) throw new Error('Voucher ini hanya berlaku untuk Daftar Ulang.');
            }

            // Calculate Discount
            let discount = 0;
            if (voucher.type === 'fixed') {
                discount = voucher.amount;
            } else {
                discount = (activeInvoice.amount * voucher.amount) / 100;
            }

            // Cap discount to not exceed amount
            if (discount > activeInvoice.amount) discount = activeInvoice.amount;

            setAppliedVoucher({
                ...voucher,
                discount_amount: discount,
                final_amount: activeInvoice.amount - discount
            });
            showToast('Voucher berhasil dipasang!', 'success');
        } catch (error) {
            showToast(error.message, 'error');
            setAppliedVoucher(null);
        } finally {
            setCalculating(false);
        }
    };

    const removeVoucher = () => {
        setAppliedVoucher(null);
        setVoucherCode('');
    };

    const submitManualPayment = async () => {
        // Handle Installment Request (Initial)
        if (isInstallment) {
            try {
                const updates = {
                    status: 'requesting_installment',
                    installment_terms_request: parseInt(installmentTerms),
                    requested_at: serverTimestamp(),
                    is_installment_request: true
                };

                await updateDoc(doc(db, 'artifacts', appId, 'users', user.uid, 'invoices', activeInvoice.id), updates);
                await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'all_invoices', activeInvoice.id), updates);

                showToast('Pengajuan cicilan berhasil dikirim. Menunggu persetujuan admin.');
                setActiveInvoice(null); setUploadProof(null); setSelectedBank(null); setAppliedVoucher(null); setVoucherCode('');
                setIsInstallment(false);
            } catch (err) { console.error(err); showToast('Gagal mengirim pengajuan.', 'error'); }
            return;
        }

        if (!uploadProof) return showToast('Bukti transfer harus diupload!', 'error');
        if (!selectedBank && payConfig.manual_banks.length > 0) return showToast('Pilih bank tujuan transfer!', 'error');

        try {
            // Handle Installment Term Payment
            if (activeTermPay !== null && activeInvoice) {
                const newSchedule = [...activeInvoice.installment_schedule];
                newSchedule[activeTermPay.index] = {
                    ...newSchedule[activeTermPay.index],
                    status: 'verifying',
                    proof_of_transfer: uploadProof,
                    paid_at: new Date().toISOString(), // Store as string for object/array safety
                    bank_destination: selectedBank || 'Manual'
                };

                const updates = {
                    installment_schedule: newSchedule,
                    // If all paid, update main status? Maybe keep it as installment_approved until admin verifies all.
                };

                await updateDoc(doc(db, 'artifacts', appId, 'users', user.uid, 'invoices', activeInvoice.id), updates);
                await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'all_invoices', activeInvoice.id), updates);

                showToast('Bukti pembayaran cicilan berhasil dikirim. Menunggu verifikasi.');
                setActiveInvoice(null); setUploadProof(null); setSelectedBank(null);
                setActiveTermPay(null);
                return;
            }

            // Normal Full Payment
            const updates = {
                status: 'verifying_payment',
                proof_of_transfer: uploadProof,
                paid_at: serverTimestamp(),
                bank_destination: selectedBank || 'Manual'
            };

            // If voucher applied, include it in updates and increment usage
            if (appliedVoucher) {
                updates.original_amount = activeInvoice.amount;
                updates.amount = appliedVoucher.final_amount; // Update main amount to discounted
                updates.discount_info = {
                    code: appliedVoucher.code,
                    amount: appliedVoucher.discount_amount,
                    type: appliedVoucher.type,
                    value: appliedVoucher.amount // percent or fixed value
                };

                // Increment voucher usage
                await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'vouchers', appliedVoucher.id), {
                    used: increment(1)
                });
            }

            await updateDoc(doc(db, 'artifacts', appId, 'users', user.uid, 'invoices', activeInvoice.id), updates);
            await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'all_invoices', activeInvoice.id), updates);
            const regUpdates = { status: 'verifying_payment' };
            if (appliedVoucher) {
                regUpdates.voucher_code = appliedVoucher.code;
            }

            await updateDoc(doc(db, 'artifacts', appId, 'users', user.uid, 'registrations', activeInvoice.registration_id), regUpdates);
            await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'all_registrations', activeInvoice.registration_id), regUpdates);

            showToast('Bukti pembayaran berhasil dikirim. Menunggu verifikasi admin.');
            setActiveInvoice(null); setUploadProof(null); setSelectedBank(null); setAppliedVoucher(null); setVoucherCode('');
        } catch (err) { console.error(err); showToast('Gagal kirim bukti.', 'error'); }
    };

    // Callback for Mock Gateway
    const onPaymentSuccess = async () => {
        try {
            const updates = { status: 'paid', paid_at: serverTimestamp(), payment_method: 'Midtrans VA', transaction_id: `MID-${Date.now()}` };
            await updateDoc(doc(db, 'artifacts', appId, 'users', user.uid, 'invoices', activeInvoice.id), updates);
            await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'all_invoices', activeInvoice.id), updates);

            // Update Registration Status
            const regDoc = await getDoc(doc(db, 'artifacts', appId, 'users', user.uid, 'registrations', activeInvoice.registration_id));
            const currentRegStatus = regDoc.data().status;
            let newRegStatus = 'verified'; // Default after payment
            if (currentRegStatus === 'lulus' || activeInvoice.description.includes('Daftar Ulang')) {
                newRegStatus = 'paid'; // Lunas
            }

            await updateDoc(doc(db, 'artifacts', appId, 'users', user.uid, 'registrations', activeInvoice.registration_id), { status: newRegStatus });
            await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'all_registrations', activeInvoice.registration_id), { status: newRegStatus });

            showToast('Pembayaran Berhasil! Status pendaftaran diperbarui.');
            setActiveInvoice(null);
        } catch (err) { console.error(err); showToast('Gagal memproses pembayaran.', 'error'); }
    };

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold flex items-center gap-2 text-slate-800"><History className="text-emerald-600" /> Riwayat Tagihan & Pembayaran</h2>

            {/* Manual Transfer Modal */}
            {activeInvoice && payConfig.gateway_active === 'manual' && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-fade-in">
                    <Card className="w-full max-w-md p-6 max-h-[90vh] overflow-y-auto">
                        <h3 className="font-bold text-lg mb-4 text-slate-800">
                            {activeTermPay ? `Bayar Cicilan #${activeTermPay.term}` : 'Transfer Manual'}
                        </h3>
                        <div className="bg-slate-50 p-4 rounded-lg mb-4 border border-slate-100">
                            <div className="text-xs text-slate-500 mb-1">Total Tagihan</div>
                            {activeTermPay ? (
                                <div className="text-2xl font-bold text-slate-800 mb-2">Rp {activeTermPay.amount.toLocaleString()}</div>
                            ) : appliedVoucher ? (
                                <div>
                                    <div className="flex items-center gap-2 text-slate-400 line-through text-sm">
                                        Rp {activeInvoice.amount.toLocaleString()}
                                    </div>
                                    <div className="text-2xl font-bold text-emerald-600 mb-2">
                                        Rp {appliedVoucher.final_amount.toLocaleString()}
                                    </div>
                                    <div className="text-xs text-emerald-600 bg-emerald-50 px-2 py-1 rounded inline-flex items-center gap-1 border border-emerald-100">
                                        <Tag size={12} /> Hemat Rp {appliedVoucher.discount_amount.toLocaleString()} ({appliedVoucher.code})
                                    </div>
                                </div>
                            ) : (
                                <div className="text-2xl font-bold text-slate-800 mb-2">Rp {activeInvoice.amount.toLocaleString()}</div>
                            )}

                            <div className="text-xs text-slate-500 mt-2 pt-2 border-t flex justify-between items-center">
                                <span>{activeInvoice.description}</span>
                                {activeInvoice.description.toLowerCase().includes('daftar ulang') && !appliedVoucher && !activeTermPay && (
                                    <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-1 rounded animate-pulse">Diskon Tersedia?</span>
                                )}
                            </div>
                        </div>

                        {/* Voucher Input - Only for Daftar Ulang - HIDDEN if Paying Specific Term */}
                        {!activeTermPay && activeInvoice.description.toLowerCase().includes('daftar ulang') && (
                            <div className="mb-4">
                                <label className="text-sm font-bold text-slate-700 block mb-2">Punya Kode Voucher?</label>
                                {appliedVoucher ? (
                                    <div className="flex justify-between items-center p-3 bg-green-50 border border-green-200 rounded-lg">
                                        <div className="flex items-center gap-2">
                                            <CheckCircle size={16} className="text-green-600" />
                                            <span className="font-bold text-green-700 text-sm">{appliedVoucher.code}</span>
                                        </div>
                                        <button onClick={removeVoucher} className="text-slate-400 hover:text-red-500"><X size={16} /></button>
                                    </div>
                                ) : (
                                    <div className="flex gap-2">
                                        <input
                                            placeholder="Masukkan Kode Voucher"
                                            value={voucherCode}
                                            onChange={e => setVoucherCode(e.target.value)}
                                            className="flex-1 px-3 py-2 border rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 uppercase"
                                        />
                                        <Button variant="secondary" onClick={handleApplyVoucher} disabled={calculating || !voucherCode} className="whitespace-nowrap">
                                            {calculating ? '...' : 'Gunakan'}
                                        </Button>
                                    </div>
                                )}
                            </div>
                        )}

                        <div className="mb-4 pt-4 border-t">
                            {/* Only Show Installment Option if NOT paying a specific term and NOT already in installment AND is Re-registration */}
                            {!activeTermPay && (activeInvoice.description?.toLowerCase().includes('daftar ulang') || activeInvoice.type === 're_registration') && (
                                <div className="flex items-start gap-3">
                                    <div className="pt-1">
                                        <input
                                            type="checkbox"
                                            id="installmentCheck"
                                            checked={isInstallment}
                                            onChange={e => setIsInstallment(e.target.checked)}
                                            className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500"
                                        />
                                    </div>
                                    <div className="flex-1">
                                        <label htmlFor="installmentCheck" className="text-sm font-bold text-slate-800 cursor-pointer select-none">
                                            Ajukan Pembayaran Bertahap (Cicilan)
                                        </label>
                                        <p className="text-xs text-slate-500 mt-1">
                                            Centang opsi ini jika Anda ingin mengajukan pembayaran secara bertahap (cicilan).
                                        </p>

                                        {isInstallment && (
                                            <div className="mt-3 bg-blue-50 border border-blue-100 p-3 rounded-lg animate-fade-in">
                                                <label className="text-xs font-bold text-slate-700 block mb-1">Rencana Termin (Durasi)</label>
                                                <select
                                                    value={installmentTerms}
                                                    onChange={e => setInstallmentTerms(e.target.value)}
                                                    className="w-full text-sm border border-slate-300 rounded px-2 py-1.5 bg-white outline-none focus:ring-2 focus:ring-blue-500"
                                                >
                                                    <option value="2">2 Bulan (2x Pembayaran)</option>
                                                    <option value="3">3 Bulan (3x Pembayaran)</option>
                                                    <option value="4">4 Bulan (4x Pembayaran)</option>
                                                </select>
                                                <p className="text-[10px] text-blue-600 mt-2">
                                                    * Besaran cicilan dan jatuh tempo akan ditentukan oleh Admin setelah pengajuan disetujui.
                                                </p>
                                                <p className="text-[10px] text-blue-600 mt-2">
                                                    * Jika Anda mengajukan pembayaran bertahap (cicilan), Diskon atau Voucher dalam bentuk apapun tidak bisa di CLAIM.
                                                </p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>

                        {!isInstallment && (<>
                            <div className="mb-4">
                                <label className="text-sm font-bold text-slate-700 block mb-2">1. Transfer ke salah satu rekening:</label>
                                <div className="space-y-2">
                                    {payConfig.manual_banks && payConfig.manual_banks.map((bank, idx) => (
                                        <div key={idx} onClick={() => setSelectedBank(`${bank.bank_name} - ${bank.account_number}`)} className={`border p-3 rounded-lg cursor-pointer transition-all flex justify-between items-center ${selectedBank?.includes(bank.account_number) ? 'border-emerald-500 bg-emerald-50 ring-1 ring-emerald-500' : 'hover:border-slate-300'}`}>
                                            <div>
                                                <div className="font-bold text-slate-800">{bank.bank_name}</div>
                                                <div className="font-mono text-slate-600 text-sm">{bank.account_number}</div>
                                                <div className="text-xs text-slate-400 mt-0.5">a.n {bank.holder_name}</div>
                                            </div>
                                            {selectedBank?.includes(bank.account_number) && <div className="w-4 h-4 rounded-full bg-emerald-500"></div>}
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="mb-6 animate-fade-in">
                                <label className="text-sm font-bold text-slate-700 block mb-2">2. Upload Bukti Transfer:</label>
                                <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:bg-slate-50 transition-colors relative">
                                    <input type="file" accept="image/*" onChange={handleManualUpload} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                                    {uploadProof ? (
                                        <div className="text-emerald-600 text-sm font-bold flex flex-col items-center gap-2">
                                            <img src={uploadProof} className="max-h-24 rounded border shadow-sm" alt="Preview" />
                                            <span>Ganti File</span>
                                        </div>
                                    ) : (
                                        <div className="text-slate-400 flex flex-col items-center gap-2">
                                            <UploadCloud size={24} />
                                            <span className="text-xs">Klik untuk upload (Max 500KB)</span>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </>)}

                        <div className="flex gap-2">
                            <Button onClick={submitManualPayment} className="flex-1 px-8">
                                {isInstallment
                                    ? 'Kirim Pengajuan Cicilan'
                                    : (activeTermPay ? `Bayar Cicilan Rp ${activeTermPay.amount.toLocaleString()}` : (appliedVoucher ? `Bayar Rp ${appliedVoucher.final_amount.toLocaleString()}` : 'Kirim Bukti Bayar'))
                                }
                            </Button>
                            <Button variant="secondary" onClick={() => { setActiveInvoice(null); setUploadProof(null); setSelectedBank(null); setAppliedVoucher(null); setVoucherCode(''); setActiveTermPay(null); }}>Batal</Button>
                        </div>
                    </Card>
                </div>
            )}

            {/* Midtrans Mock Modal */}
            <MidtransMock isOpen={!!activeInvoice && payConfig.gateway_active === 'midtrans'} onClose={() => setActiveInvoice(null)} invoice={activeInvoice} onSuccess={onPaymentSuccess} />

            <div className="space-y-4">
                {invoices.length === 0 ? (
                    <div className="text-slate-400 text-center py-10 bg-white rounded-xl border border-dashed text-sm">Belum ada history tagihan.</div>
                ) : (
                    invoices.map(inv => (
                        <Card key={inv.id} className="p-4 md:p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:shadow-md transition-shadow">
                            <div className="flex items-start gap-4">
                                <div className={`p-3 rounded-full mt-1 ${inv.status === 'paid' ? 'bg-green-100 text-green-600' : (inv.status === 'pending' ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600')}`}>
                                    {inv.status === 'paid' ? <CheckCircle size={24} /> : (inv.status === 'pending' ? <Wallet size={24} /> : <History size={24} />)}
                                </div>
                                <div>
                                    <h4 className="font-bold text-slate-800 text-lg">Rp {inv.amount.toLocaleString()}</h4>
                                    <p className="font-medium text-slate-600 text-sm">{inv.description}</p>
                                    <p className="text-xs text-slate-400 mt-1">{inv.student_name} • {new Date(inv.created_at?.seconds * 1000).toLocaleDateString()}</p>
                                    {inv.payment_method && <span className="text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500 mt-2 inline-block font-mono">Via {inv.payment_method}</span>}
                                </div>
                            </div>
                            <div className="flex flex-col items-end gap-2 w-full md:w-auto">
                                <Badge status={inv.status} />
                                {inv.status === 'pending' && !inv.is_installment && (
                                    <Button onClick={() => handlePay(inv)} className="w-full md:w-auto text-xs py-2 px-4 shadow-orange-100 bg-orange-500 hover:bg-orange-600">
                                        <CreditCard size={14} className="mr-1" /> Bayar Sekarang
                                    </Button>
                                )}
                                {inv.status === 'installment_approved' && (
                                    <Button onClick={() => setViewInstallment(inv)} className="w-full md:w-auto text-xs py-2 px-4 shadow-blue-100 bg-blue-500 hover:bg-blue-600">
                                        <Clock size={14} className="mr-1" /> Lihat Cicilan
                                    </Button>
                                )}
                                {inv.status === 'requesting_installment' && (
                                    <span className="text-xs text-orange-500 italic bg-orange-50 px-2 py-1 rounded border border-orange-100">
                                        Verifikasi Pengajuan Cicilan
                                    </span>
                                )}
                                {inv.status === 'paid' && (
                                    <Button variant="secondary" onClick={() => setViewInvoice(inv)} className="w-full md:w-auto text-xs py-1.5 px-3">
                                        <Printer size={14} className="mr-1" /> Cetak Invoice
                                    </Button>
                                )}
                                {inv.status === 'verifying_payment' && <span className="text-xs text-slate-400 italic">Menunggu verifikasi admin</span>}
                            </div>
                        </Card>
                    ))
                )}
                {/* Installment Detail Modal */}
                <Modal
                    isOpen={!!viewInstallment}
                    onClose={() => setViewInstallment(null)}
                    title="Rencana Pembayaran Cicilan"
                    maxWidth="max-w-lg"
                >
                    {viewInstallment && (
                        <div className="space-y-4">
                            <div className="bg-slate-50 p-4 rounded-lg flex justify-between items-center">
                                <div>
                                    <span className="text-xs text-slate-500 block">Total Tagihan</span>
                                    <span className="font-bold text-slate-800">Rp {viewInstallment.amount.toLocaleString()}</span>
                                </div>
                                <div className="text-right">
                                    <span className="text-xs text-slate-500 block">Sisa Pembayaran</span>
                                    <span className="font-bold text-red-600">
                                        Rp {(viewInstallment.installment_schedule.reduce((acc, curr) => curr.status === 'paid' ? acc : acc + curr.amount, 0)).toLocaleString()}
                                    </span>
                                </div>
                            </div>

                            <div className="space-y-3">
                                {viewInstallment.installment_schedule.map((term, idx) => {
                                    const dueDateSafe = term.due_date ? new Date(term.due_date) : new Date();
                                    const isValidDate = !isNaN(dueDateSafe.getTime());

                                    return (
                                        <div key={idx} className={`border rounded-lg p-3 flex justify-between items-center ${term.status === 'paid' ? 'bg-green-50 border-green-200' : 'bg-white border-slate-200'}`}>
                                            <div>
                                                <div className="flex items-center gap-2">
                                                    <span className="text-sm font-bold text-slate-700">Cicilan #{term.term}</span>
                                                    {term.status === 'paid' && <Badge status="paid" />}
                                                    {term.status === 'verifying' && <Badge status="processing">Verifikasi</Badge>}
                                                </div>
                                                <div className="text-xs text-slate-500 mt-1">
                                                    Jatuh Tempo: {isValidDate ? dueDateSafe.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }) : '-'}
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <div className="font-bold text-slate-800 mb-1">Rp {term.amount.toLocaleString()}</div>
                                                {term.status === 'unpaid' && (
                                                    <Button size="sm" onClick={() => {
                                                        setActiveInvoice(viewInstallment); // Use same invoice
                                                        setActiveTermPay({ index: idx, ...term }); // Set term context
                                                        setViewInstallment(null); // Close list modal, open payment modal
                                                    }}>
                                                        Bayar
                                                    </Button>
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>

                            <div className="flex justify-end pt-2">
                                <Button variant="secondary" onClick={() => setViewInstallment(null)}>Tutup</Button>
                            </div>
                        </div>
                    )}
                </Modal>

            </div>

            {/* Printable Invoice Modal */}
            <Modal
                isOpen={!!viewInvoice}
                onClose={() => setViewInvoice(null)}
                title="Cetak Invoice Formal"
                maxWidth="max-w-5xl"
                footer={
                    <div className="flex justify-end gap-2 w-full print:hidden">
                        <Button variant="secondary" onClick={() => setViewInvoice(null)}>Tutup</Button>
                        <Button variant="secondary" onClick={handleDownloadPDF}><Download size={16} /></Button>
                        <Button variant="secondary" onClick={handleShare}><Share2 size={16} /></Button>
                        <Button onClick={() => window.print()}><Printer size={16} className="mr-2" /> Cetak</Button>
                    </div>
                }
            >
                {viewInvoice && (
                    <div className="w-full bg-slate-200 p-4 md:p-8 overflow-auto flex justify-center">
                        <div
                            className="bg-white text-slate-900 shadow-2xl mx-auto relative flex flex-col"
                            style={{
                                width: '210mm',
                                minHeight: '297mm',
                                padding: '15mm',
                                boxSizing: 'border-box'
                            }}
                            id="invoice-print"
                            ref={invoiceRef}
                        >
                            {/* Formal Header */}
                            <div className="flex justify-between items-center border-b-4 border-double border-slate-800 pb-6 mb-8 gap-6">
                                {/* LOGO SEKOLAH */}
                                {settings.app_logo && (
                                    <div className="w-24 h-24 flex-shrink-0 flex items-center justify-center">
                                        <img src={settings.app_logo} className="w-full h-full object-contain" alt="Logo" />
                                    </div>
                                )}

                                <div className="flex-1">
                                    <h1 className="text-3xl font-serif font-black text-slate-900 uppercase tracking-wide leading-tight mb-2">
                                        {settings.school_name || 'Sekolah Islam Terpadu Cendekia'}
                                    </h1>
                                    <div className="text-sm font-serif text-slate-600 leading-snug">
                                        <p>{settings.school_address || 'Jl. Pendidikan No. 1, Kota Bogor, Jawa Barat'}</p>
                                        <p>Telp: {settings.school_phone || '(0251) 8312345'} | Email: {settings.school_email || 'admin@sekolahku.sch.id'}</p>
                                    </div>
                                </div>
                                <div className="text-right flex-shrink-0">
                                    <h2 className="text-5xl font-serif font-bold text-slate-100 tracking-widest select-none">INVOICE</h2>
                                </div>
                            </div>

                            {/* Info Grid */}
                            <div className="flex justify-between items-start mb-10 font-serif">
                                <div className="w-1/2 pr-8 border-r border-slate-100">
                                    <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Ditagihkan Kepada:</h3>
                                    <p className="text-xl font-bold text-slate-900">{viewInvoice.student_name}</p>
                                    <p className="text-sm text-slate-600 italic mt-1">Wali Murid / Orang Tua</p>
                                    <div className="mt-4 pt-4 border-t border-slate-100">
                                        <p className="text-xs text-slate-500">ID Registrasi:</p>
                                        <p className="font-mono text-sm">{viewInvoice.registration_id.slice(0, 8).toUpperCase()}</p>
                                    </div>
                                </div>
                                <div className="w-1/2 pl-8 flex flex-col items-end text-right">
                                    <div className="mb-4">
                                        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Nomor Invoice</h3>
                                        <p className="text-lg font-mono font-bold text-slate-900">
                                            {viewInvoice.invoice_number_formatted ?
                                                `#${viewInvoice.invoice_number_formatted}` :
                                                `#${settings.invoice_prefix || ''}${viewInvoice.id.slice(0, 10).toUpperCase()}`
                                            }
                                        </p>
                                    </div>
                                    <div className="mb-4">
                                        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Tanggal & Waktu Bayar</h3>
                                        <p className="font-serif text-lg text-slate-800">
                                            {viewInvoice.paid_at ? new Date(viewInvoice.paid_at.seconds * 1000).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }) : '-'}
                                        </p>
                                        <p className="text-xs text-slate-500">
                                            {viewInvoice.paid_at ? new Date(viewInvoice.paid_at.seconds * 1000).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) + ' WIB' : ''}
                                        </p>
                                    </div>
                                    <div className="border border-green-200 bg-green-50 text-green-700 px-4 py-2 rounded text-sm font-bold uppercase tracking-widest">
                                        LUNAS / PAID
                                    </div>
                                </div>
                            </div>

                            {/* Table */}
                            <div className="mb-8 flex-1">
                                <table className="w-full border-collapse">
                                    <thead>
                                        <tr className="border-y-2 border-slate-800">
                                            <th className="py-3 text-left font-serif font-bold text-slate-800 uppercase text-sm w-[60%]">Deskripsi Layanan</th>
                                            <th className="py-3 text-right font-serif font-bold text-slate-800 uppercase text-sm">Nominal (Rp)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td className="py-6 border-b border-slate-200 align-top">
                                                <p className="font-bold text-lg text-slate-800 mb-1">{viewInvoice.description}</p>
                                                <p className="text-sm text-slate-500 font-serif">Pembayaran Administrasi Sekolah</p>

                                                {viewInvoice.is_installment && (
                                                    <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded text-sm font-mono">
                                                        <p className="font-bold text-slate-700 underline mb-1">Rincian Cicilan:</p>
                                                        <ul className="list-disc list-inside">
                                                            {viewInvoice.installment_schedule?.map((t, idx) => (
                                                                <li key={idx} className={t.status === 'paid' ? 'text-green-600' : 'text-slate-500'}>
                                                                    Term {t.term}: Rp {t.amount.toLocaleString()} ({t.status})
                                                                </li>
                                                            ))}
                                                        </ul>
                                                    </div>
                                                )}

                                                {viewInvoice.discount_info && (
                                                    <div className="mt-2 text-sm text-emerald-600 italic">
                                                        Termasuk Potongan Voucher: {viewInvoice.discount_info.code}
                                                    </div>
                                                )}
                                            </td>
                                            <td className="py-6 border-b border-slate-200 text-right align-top">
                                                <p className="font-mono text-lg text-slate-800">
                                                    Rp {(viewInvoice.original_amount || viewInvoice.amount).toLocaleString()}
                                                </p>
                                                {viewInvoice.discount_info && (
                                                    <p className="font-mono text-sm text-red-500">
                                                        - Rp {viewInvoice.discount_info.amount.toLocaleString()}
                                                    </p>
                                                )}
                                            </td>
                                        </tr>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td className="pt-4 text-right font-serif font-bold text-slate-600 uppercase pr-8">Total Pembayaran</td>
                                            <td className="pt-4 text-right font-mono font-bold text-2xl text-slate-900 border-t-2 border-slate-800 mt-2 block">
                                                Rp {viewInvoice.amount.toLocaleString()}
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>

                            {/* Footer / Signature */}
                            <div className="mt-auto pt-16 grid grid-cols-2 gap-16 items-end">
                                <div>
                                    <h4 className="font-bold text-slate-800 text-sm mb-2">Metode Pembayaran:</h4>
                                    <div className="p-3 border border-slate-200 rounded text-sm text-slate-600 bg-slate-50 mb-6">
                                        <p>{viewInvoice.payment_method || 'Manual Transfer'}</p>
                                        {viewInvoice.bank_destination && <p className="font-mono text-xs mt-1">{viewInvoice.bank_destination}</p>}
                                    </div>
                                    <div className="text-xs text-slate-400 leading-relaxed font-serif">
                                        {settings.invoice_footer_note || 'Bukti pembayaran ini adalah dokumen sah yang diterbitkan sistem komputerisasi.'}
                                    </div>
                                </div>
                                <div className="text-center">
                                    <p className="text-sm font-serif text-slate-600 mb-6">
                                        {settings.school_address?.split(',')[1] || 'Kota Bogor'}, {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}
                                    </p>

                                    <div className="relative h-28 w-full flex items-center justify-center mb-2">
                                        {(settings.finance_signature || settings.signature_image) && (
                                            <img src={settings.finance_signature || settings.signature_image} className="h-full w-auto object-contain mix-blend-multiply opacity-90" alt="Tanda Tangan" style={{ maxWidth: '150px' }} />
                                        )}
                                    </div>

                                    <p className="font-bold text-slate-800 uppercase text-sm border-b border-slate-800 inline-block px-4 pb-1">
                                        {settings.finance_head || settings.committee_head || 'Bendahara Sekolah'}
                                    </p>
                                    <p className="text-xs text-slate-500 mt-1">
                                        {settings.finance_position || 'Bagian Keuangan'}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </Modal>
        </div>
    );
}
