import React, { useState, useEffect } from 'react';
import {
    collection, getDocs, getDoc, doc, addDoc, updateDoc,
    serverTimestamp, increment, query, where, setDoc, onSnapshot
} from 'firebase/firestore';
import {
    User, FileText, MapPin, Building, GraduationCap, CheckCircle,
    Activity, School, CheckSquare, Users, Upload, Info, Clock, Send
} from 'lucide-react';
import { db, appId } from '../../config/firebase';
import { Card, Button, Input, Select, Badge } from '../ui/Elements';
import { Modal } from '../ui/Overlays';
import { fetchRegionData, fileToBase64 } from '../../utils/helpers';

export default function RegistrationWizard({ user, onComplete, showToast, initialIndent, isInternal = false }) {
    const [step, setStep] = useState(1);
    const [branches, setBranches] = useState([]);
    const [paths, setPaths] = useState([]);
    const [waves, setWaves] = useState([]);
    const [indentWaves, setIndentWaves] = useState([]);
    const [isIndentMode, setIsIndentMode] = useState(initialIndent || false);
    const [academicYears, setAcademicYears] = useState([]);
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        unit_id: '', major: '', path_id: '', wave_id: '',
        student_new: {
            name: '', nickname: '', gender: 'L', pob: '', dob: '', nik: '', kk: '',
            religion: 'Islam', nationality: 'Indonesia',
            child_order: '', siblings_count: '', siblings_step: '', siblings_adopted: '',
            orphan_status: 'Lengkap', daily_language: 'Indonesia',
            height: '', weight: '', blood_type: '', diseases: '', diseases_hospital: '',
            allergies: '', special_needs: '', physical_disability: ''
        },
        education: {
            origin_school: '', npsn: '', school_status: 'Negeri', grad_year: '',
            diploma_no: '', diploma_date: '', study_duration: '',
            grade_math: '', grade_ind: '', grade_eng: '', grade_ipa: '', achievements: ''
        },
        address: {
            street: '', village: '', district: '', regency: '', province: '', postal_code: '',
            phone: '', address_status: 'Milik Sendiri', distance: '', transport_mode: '',
            residence_status: 'Orang Tua'
        },
        father: { name: '', nik: '', job: '', education: '', income: '', phone: '' },
        mother: { name: '', nik: '', job: '', education: '', income: '', phone: '' },
        guardian: { name: '', relation: '', phone: '' },
        documents: { kk: null, akta: null, rapor: null, surat_sehat: null, sktm: null, photo_student: null },
        agreed_health: false
    });
    const [uploadingDocs, setUploadingDocs] = useState({ kk: false, akta: false, rapor: false, surat_sehat: false, sktm: false, photo_student: false });
    const [regions, setRegions] = useState({ provinces: [], regencies: [], districts: [], villages: [] });
    const [regionIds, setRegionIds] = useState({ province: '', regency: '', district: '' });
    const [indentStats, setIndentStats] = useState({}); // { [unitId]: { filled: 0, majors: { [name]: 0 } } }

    // Indent Verification State (Internal Only)
    const [indentSubmission, setIndentSubmission] = useState(null);
    const [uploadModalOpen, setUploadModalOpen] = useState(false);
    const [recommendationFile, setRecommendationFile] = useState(null);
    const [uploadingRec, setUploadingRec] = useState(false);
    const [recStudentName, setRecStudentName] = useState('');
    const [recUnitId, setRecUnitId] = useState('');
    const [checkingIndent, setCheckingIndent] = useState(isInternal); // Start checking if internal

    const incomeOptions = [{ value: 'range_1', label: 'Rp 10.000.000 – Rp 14.999.999' }, { value: 'range_2', label: 'Rp 15.000.000 – Rp 19.999.999' }, { value: 'range_3', label: 'Rp 20.000.000 – Rp 29.999.999' }, { value: 'range_4', label: 'Rp 30.000.000 – Rp 39.999.999' }, { value: 'range_5', label: 'Rp 40.000.000 – Rp 49.999.999' }, { value: 'range_6', label: 'Rp 50.000.000 – Rp 59.999.999' }, { value: 'range_7', label: 'Rp 60.000.000 – Rp 69.999.999' }, { value: 'range_8', label: 'Rp 70.000.000 – Rp 79.999.999' }, { value: 'range_9', label: 'Rp 80.000.000 – Rp 89.999.999' }, { value: 'range_10', label: 'Rp 90.000.000 – Rp 100.000.000' }, { value: 'range_11', label: 'Di atas Rp 100.000.000' }, { value: 'range_0', label: 'Di bawah Rp 10.000.000' }];

    useEffect(() => {
        if (isInternal) {
            const unsub = onSnapshot(doc(db, 'artifacts', appId, 'indent_submissions', user.uid), d => {
                const data = d.exists() ? { id: d.id, ...d.data() } : null;
                setIndentSubmission(data);

                // If not approved, force modal open
                if (!data || data.status === 'rejected' || data.status === 'pending') {
                    // actually we will handle the "blocking" in the render
                    setUploadModalOpen(!data || data.status === 'rejected'); // Open upload if null or rejected
                }
                setCheckingIndent(false);
            });
            return () => unsub();
        } else {
            setCheckingIndent(false);
        }
    }, [isInternal, user.uid]);

    useEffect(() => {
        setIsIndentMode(initialIndent || false);
        setFormData(prev => ({ ...prev, wave_id: '', unit_id: '', major: '' })); // Reset selection on mode change
    }, [initialIndent]);

    useEffect(() => {
        const fetchQuotaStats = async () => {
            // Determine Target Year STRING (e.g., "2026/2027" or "2025/2026")
            let targetYearString = null;

            if (isIndentMode) {
                // For Indent Mode: Get year from selected wave or first indent wave
                if (formData.wave_id) {
                    const w = indentWaves.find(iw => iw.id === formData.wave_id);
                    if (w) targetYearString = w.year;
                } else if (indentWaves.length > 0) {
                    targetYearString = indentWaves[0].year;
                }
            } else {
                // For Regular Mode: Use the default/active year
                const defaultYear = academicYears.find(y => y.is_default);
                if (defaultYear) targetYearString = defaultYear.year;
            }

            if (!targetYearString) {
                setIndentStats({});
                return;
            }

            try {
                // Fetch ALL registrations for this academic year
                // Using 'academic_year' field (same as AdminQuotaMonitoring)
                const TAKEN_STATUS = ['submitted', 'verified', 'verifying_payment', 'paid', 'paid_registration', 'accepted', 'lulus', 're_registration', 'student', 'psychotest_done', 'interview_accepted'];

                const q = query(
                    collection(db, 'artifacts', appId, 'public', 'data', 'all_registrations'),
                    where('academic_year', '==', targetYearString)
                );

                const snap = await getDocs(q);
                const stats = {};

                snap.docs.forEach(d => {
                    const data = d.data();

                    // Only count taken statuses
                    if (!TAKEN_STATUS.includes(data.status)) return;

                    const uid = data.unit_id;
                    if (!stats[uid]) stats[uid] = { filled: 0, majors: {} };

                    stats[uid].filled++;

                    // Check Major
                    const major = data.accepted_major || data.major || data.major_1;
                    if (major) {
                        if (!stats[uid].majors[major]) stats[uid].majors[major] = 0;
                        stats[uid].majors[major]++;
                    }
                });

                setIndentStats(stats);
                console.log('Quota Stats Loaded for year:', targetYearString, stats);
            } catch (e) {
                console.error("Failed to fetch quota stats:", e);
                setIndentStats({});
            }
        };

        if (academicYears.length > 0) fetchQuotaStats();
    }, [isIndentMode, formData.wave_id, academicYears, indentWaves]);


    useEffect(() => {
        const fd = async () => {
            const uSnap = await getDocs(collection(db, 'artifacts', appId, 'public', 'data', 'units'));
            setBranches(uSnap.docs.map(d => ({ id: d.id, ...d.data() })));

            const pSnap = await getDocs(collection(db, 'artifacts', appId, 'public', 'data', 'paths'));
            setPaths(pSnap.docs.map(d => ({ id: d.id, ...d.data() })));

            // Fetch all academic years
            const aySnap = await getDocs(collection(db, 'artifacts', appId, 'public', 'data', 'academic_years'));
            const allAcademicYears = aySnap.docs.map(d => ({ id: d.id, ...d.data() }));
            setAcademicYears(allAcademicYears);

            // Find the DEFAULT academic year (the current active one)
            const defaultAcademicYear = allAcademicYears.find(ay => ay.is_default);
            const defaultYearName = defaultAcademicYear?.year;

            // Filter indent-enabled academic years (for indent registration - excluding default)
            const indentAcademicYears = allAcademicYears.filter(ay => ay.indent_enabled && !ay.is_default);
            const indentYearNames = indentAcademicYears.map(ay => ay.year);

            // Fetch all waves
            const wSnap = await getDocs(collection(db, 'artifacts', appId, 'public', 'data', 'waves'));
            const allWaves = wSnap.docs.map(d => ({ id: d.id, ...d.data() }));

            // Regular waves: active waves from DEFAULT academic year only
            if (defaultYearName) {
                setWaves(allWaves.filter(w => w.active && w.year === defaultYearName));
            } else {
                setWaves([]); // No default set
            }

            // Indent waves: active waves from indent-enabled academic years (not the default)
            // AND current date must be within indent_start_date and indent_end_date
            // Fetch Internal Indent Settings
            const internalSettingsSnap = await getDoc(doc(db, 'artifacts', appId, 'public', 'settings_indent_internal'));
            const internalSettings = internalSettingsSnap.exists() ? internalSettingsSnap.data() : null;

            // Indent waves logic
            const today = new Date().toISOString().split('T')[0];
            let validIndentYearNames = [];

            if (isInternal && internalSettings?.active && internalSettings?.target_academic_years) {
                // For Internal Indent, strict adherence to settings
                validIndentYearNames = internalSettings.target_academic_years;
            } else {
                // For External Indent (or fallback), use active indent periods from Academic Years
                const validIndentYears = indentAcademicYears.filter(ay => {
                    if (!ay.indent_start_date || !ay.indent_end_date) return false;
                    return today >= ay.indent_start_date && today <= ay.indent_end_date;
                });
                validIndentYearNames = validIndentYears.map(ay => ay.year);
            }

            setIndentWaves(allWaves.filter(w => w.active && validIndentYearNames.includes(w.year)));

            // BLOCKING LOGIC: Check active registrations
            const regQuery = query(collection(db, 'artifacts', appId, 'users', user.uid, 'registrations'), where('status', 'in', ['submitted', 'verifying_payment']));
            const regSnap = await getDocs(regQuery);
            // ... (rest of blocking logic)
            if (!regSnap.empty) {
                showToast("Anda memiliki pendaftaran yang belum lunas. Harap selesaikan terlebih dahulu.", 'error');
                onComplete(); // Navigate back to dashboard
            }
        };
        fd();
        fetchRegionData('provinces').then(data => setRegions(prev => ({ ...prev, provinces: data })));
    }, []);

    const handleNestedChange = (category, field, value) => { setFormData(prev => ({ ...prev, [category]: { ...prev[category], [field]: value } })); };
    const handleMainChange = (field, value) => { setFormData(prev => ({ ...prev, [field]: value })); };

    // FIX: Updated handleRegionChange to fetch data first, then set state
    const handleRegionChange = async (level, id, name) => {
        const newIds = { ...regionIds };
        const newAddress = { ...formData.address };

        if (level === 'province') {
            newIds.province = id; newIds.regency = ''; newIds.district = '';
            newAddress.province = name; newAddress.regency = ''; newAddress.district = ''; newAddress.village = '';

            // Reset and Fetch Regencies
            setRegions(prev => ({ ...prev, regencies: [], districts: [], villages: [] }));
            const data = await fetchRegionData('regencies', id);
            setRegions(prev => ({ ...prev, regencies: data }));
        }
        else if (level === 'regency') {
            newIds.regency = id; newIds.district = '';
            newAddress.regency = name; newAddress.district = ''; newAddress.village = '';

            // Reset and Fetch Districts
            setRegions(prev => ({ ...prev, districts: [], villages: [] }));
            const data = await fetchRegionData('districts', id);
            setRegions(prev => ({ ...prev, districts: data }));
        }
        else if (level === 'district') {
            newIds.district = id;
            newAddress.district = name; newAddress.village = '';

            // Reset and Fetch Villages
            setRegions(prev => ({ ...prev, villages: [] }));
            const data = await fetchRegionData('villages', id);
            setRegions(prev => ({ ...prev, villages: data }));
        }
        else if (level === 'village') {
            newAddress.village = name;
        }

        setRegionIds(newIds);
        setFormData(prev => ({ ...prev, address: newAddress }));
    };

    const uploadFile = async (type, file) => {
        if (!file) return; setUploadingDocs(prev => ({ ...prev, [type]: true }));
        try { const base64Data = await fileToBase64(file); setFormData(prev => ({ ...prev, documents: { ...prev.documents, [type]: base64Data } })); showToast('Dokumen berhasil diupload (Lokal)!'); } catch (error) { showToast(error.message, 'error'); } finally { setUploadingDocs(prev => ({ ...prev, [type]: false })); }
    };
    const selectedBranch = branches.find(u => u.id === formData.unit_id);
    const selectedWave = waves.find(w => w.id === formData.wave_id) || indentWaves.find(w => w.id === formData.wave_id);

    const handleSubmit = async () => {
        if (!formData.agreed_health) return showToast('Harap setujui pernyataan kesehatan anak.', 'error');
        setLoading(true);
        try {
            // 1. REAL-TIME QUOTA CHECK
            const unitRef = doc(db, 'artifacts', appId, 'public', 'data', 'units', selectedBranch.id);
            const latestUnitSnap = await getDoc(unitRef);

            if (!latestUnitSnap.exists()) throw new Error("Data unit sekolah tidak ditemukan.");
            const latestUnit = latestUnitSnap.data();

            // Resolve Quota Source (Active vs Indent Year)
            let targetYearId = null;
            if (isIndentMode) {
                if (formData.wave_id) {
                    const w = indentWaves.find(iw => iw.id === formData.wave_id);
                    if (w) targetYearId = academicYears.find(y => y.year === w.year)?.id;
                }
            } else {
                targetYearId = academicYears.find(y => y.is_default)?.id;
            }

            const config = (targetYearId && latestUnit.academic_configs?.[targetYearId]) || {};
            // If indent mode but no config, fallback to root? Assuming root is default year. 
            // Better to use config if available, else root.

            const activeMajors = config.majors || latestUnit.majors || [];

            let isFull = false;

            if (activeMajors.length > 0 && formData.major) {
                const majorData = activeMajors.find(m => m.name === formData.major);
                if (majorData) {
                    const q = parseInt(majorData.quota) || 0;
                    const f = parseInt(majorData.filled) || 0;
                    if (f >= q) isFull = true;
                }
            } else {
                // Check unit quota
                const q = config.quota !== undefined ? parseInt(config.quota) : (parseInt(latestUnit.quota) || 0);
                const f = config.filled !== undefined ? parseInt(config.filled) : (parseInt(latestUnit.filled) || 0);
                if (f >= q) isFull = true;
            }

            if (isFull) {
                showToast('Mohon maaf, kuota pendaftaran untuk pilihan ini telah PENUH.', 'error');
                // Refresh branches data to reflect UI
                const uSnap = await getDocs(collection(db, 'artifacts', appId, 'public', 'data', 'units'));
                setBranches(uSnap.docs.map(d => ({ id: d.id, ...d.data() })));
                setLoading(false);
                return;
            }

            const pathName = paths.find(p => p.id === formData.path_id)?.name || 'Unknown';
            // Check if scholarship path (Prestasi or Yatim) - applies to both Regular and Indent
            const isScholarship = pathName.toLowerCase().includes('prestasi') || pathName.toLowerCase().includes('yatim');

            const studentData = { ...formData.student_new, education: formData.education, address: formData.address, parents: { father: formData.father, mother: formData.mother, guardian: formData.guardian }, created_at: serverTimestamp() };
            const sRef = await addDoc(collection(db, 'artifacts', appId, 'users', user.uid, 'students'), studentData);

            // Determine path_name and category based on Indent mode and scholarship status
            let finalPathName = pathName;
            let finalCategory = 'Reguler';

            if (isIndentMode) {
                if (isScholarship) {
                    // Indent + Prestasi/Yatim
                    finalPathName = `Inden ${isInternal ? 'Internal' : 'Eksternal'} ${pathName}`;
                    finalCategory = `Inden ${isInternal ? 'Internal' : 'Eksternal'} ${pathName}`;
                } else {
                    // Indent + Regular path
                    finalPathName = `Inden ${isInternal ? 'Internal' : 'Eksternal'} Reguler`;
                    finalCategory = `Inden ${isInternal ? 'Internal' : 'Eksternal'} Reguler`;
                }
            } else {
                // Regular mode - use pathName as-is
                finalCategory = pathName;
            }

            const regData = {
                student_id: sRef.id,
                student_name: formData.student_new.name,
                student_religion: formData.student_new.religion,
                unit_id: formData.unit_id,
                unit_name: selectedBranch?.name || 'Unknown',
                unit_level: selectedBranch?.level || 'Unknown',
                major: formData.major || null,
                path_id: formData.path_id,
                path_name: finalPathName,
                wave_id: formData.wave_id,
                wave_name: selectedWave ? `${selectedWave.year} - ${selectedWave.name}` : 'Unknown',
                academic_year: selectedWave?.year || 'Unknown',
                category: finalCategory,
                status: 'submitted', // All registrations start with submitted, then verified by admin
                is_indent: isIndentMode,
                is_scholarship: isScholarship, // Flag for fee exemption (skip payment after verified)
                uploaded_docs: formData.documents,
                cost_reg: isScholarship ? 0 : (selectedBranch?.cost_reg || 0), // Free for scholarship
                cost_rereg: isScholarship ? 0 : (selectedBranch?.cost_rereg || 0), // Free for scholarship
                created_at: serverTimestamp()
            };
            const regRef = await addDoc(collection(db, 'artifacts', appId, 'users', user.uid, 'registrations'), regData);

            // Update Quota (Using latestUnit data to be safe)
            if (activeMajors.length > 0 && formData.major) {
                const updatedMajors = activeMajors.map(m => m.name === formData.major ? { ...m, filled: (parseInt(m.filled) || 0) + 1 } : m);
                await updateDoc(unitRef, { majors: updatedMajors, filled: increment(1) });
            } else {
                await updateDoc(unitRef, { filled: increment(1) });
            }

            await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'all_registrations', regRef.id), { ...regData, user_id: user.uid, parent_name: user.displayName, id: regRef.id });

            // Create Invoice (User & Public) - Only for NON-scholarship registrations
            const unitFee = selectedBranch?.cost_reg !== undefined ? selectedBranch.cost_reg : 0;

            if (!isScholarship) {
                const invStatus = 'pending';
                const invAmount = unitFee;

                let invDesc = `Biaya Pendaftaran ${selectedBranch?.name}`;
                if (isIndentMode) {
                    invDesc = `Biaya Pendaftaran Indent ${isInternal ? 'Internal' : 'Eksternal'} - ${selectedBranch?.name}`;
                }

                const invData = { registration_id: regRef.id, amount: invAmount, description: invDesc, status: invStatus, created_at: serverTimestamp(), student_name: formData.student_new.name, user_id: user.uid };
                const invRef = await addDoc(collection(db, 'artifacts', appId, 'users', user.uid, 'invoices'), invData);
                await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'all_invoices', invRef.id), { ...invData, id: invRef.id });
            }

            onComplete(); showToast('Pendaftaran berhasil disimpan!');
        } catch (err) { showToast(err.message, 'error'); } finally { setLoading(false); }
    };
    const renderNav = (prevStep, nextStep, disableNext) => (
        <div className="mt-12 flex justify-between items-center pt-8 border-t border-slate-100">
            {prevStep ? (
                <Button variant="secondary" onClick={() => setStep(prevStep)} className="px-8 rounded-2xl group flex items-center gap-2 font-black uppercase tracking-widest text-[10px]">
                    <span className="group-hover:-translate-x-1 transition-transform">&larr;</span> Sebelumnya
                </Button>
            ) : <div />}
            {nextStep ? (
                <Button
                    onClick={() => {
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                        setStep(nextStep);
                    }}
                    disabled={disableNext}
                    className="px-10 rounded-2xl bg-emerald-600 hover:bg-emerald-700 shadow-lg shadow-emerald-100 group flex items-center gap-2 font-black uppercase tracking-widest text-[10px]"
                >
                    Selanjutnya <span className="group-hover:translate-x-1 transition-transform">&rarr;</span>
                </Button>
            ) : (
                <Button
                    onClick={handleSubmit}
                    disabled={disableNext || loading}
                    className="px-10 rounded-2xl bg-emerald-600 hover:bg-emerald-700 shadow-xl shadow-emerald-100 font-black uppercase tracking-widest text-[10px]"
                >
                    {loading ? 'Memproses...' : 'Submit Pendaftaran'}
                </Button>
            )}
        </div>
    );

    const steps_list = [
        { title: 'Personal', icon: User },
        { title: 'Pendidikan', icon: GraduationCap },
        { title: 'Alamat', icon: MapPin },
        { title: 'Keluarga', icon: Users },
        { title: 'Pilihan', icon: School },
        { title: 'Dokumen', icon: FileText },
        { title: 'Review', icon: CheckSquare }
    ];

    const handleSubmitRecommendation = async () => {
        if (!recommendationFile || !recStudentName.trim() || !recUnitId) return showToast('Mohon lengkapi Nama, Cabang, dan File Rekomendasi.', 'error');
        setUploadingRec(true);
        try {
            const base64 = await fileToBase64(recommendationFile);
            const targetUnit = branches.find(b => b.id === recUnitId);
            await setDoc(doc(db, 'artifacts', appId, 'indent_submissions', user.uid), {
                user_id: user.uid,
                parent_name: user.displayName || 'User',
                user_email: user.email,
                student_name_candidate: recStudentName,
                target_unit_id: recUnitId,
                target_unit_name: targetUnit?.name || 'Unknown',
                recommendation_doc: base64,
                status: 'pending',
                created_at: serverTimestamp(),
                updated_at: serverTimestamp()
            });
            showToast('Surat rekomendasi terkirim. Mohon tunggu verifikasi.');
            setUploadModalOpen(false);
            setRecommendationFile(null);
            setRecStudentName('');
            setRecUnitId('');
        } catch (e) {
            console.error(e);
            showToast('Gagal upload dokumen.', 'error');
        } finally {
            setUploadingRec(false);
        }
    };

    if (checkingIndent) {
        return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div></div>;
    }

    if (isInternal && (!indentSubmission || indentSubmission.status !== 'approved')) {
        // Block access and show placeholder (Modal will be triggered by useEffect/logic below)
        // But we also render the Modal here to ensure it exists in the DOM
    }

    // We can conditionally render the main wizard OR a "Waiting" screen if not approved.
    if (isInternal && (!indentSubmission || indentSubmission.status !== 'approved')) {
        return (
            <div className="max-w-4xl mx-auto px-4 py-12 text-center">
                <Card className="p-12 border-2 border-dashed border-slate-200 bg-white dark:bg-slate-900 rounded-[2.5rem]">
                    <div className="w-24 h-24 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6">
                        <FileText size={48} className="text-slate-300" />
                    </div>
                    <h3 className="text-2xl font-black text-slate-800 dark:text-white uppercase tracking-tight mb-2">Verifikasi Diperlukan</h3>
                    <p className="text-slate-500 dark:text-slate-400 mb-8 max-w-lg mx-auto">
                        {indentSubmission
                            ? (indentSubmission.status === 'pending' ? 'Surat rekomendasi Anda sedang diverifikasi oleh Admin. Mohon tunggu hingga disetujui untuk melanjutkan pendaftaran.' : 'Surat rekomendasi Anda ditolak. Silakan upload ulang.')
                            : 'Anda harus mengupload Surat Rekomendasi dari Kepala Sekolah/Yayasan untuk melanjutkan pendaftaran jalur Inden Internal.'}
                    </p>

                    {(!indentSubmission || indentSubmission.status === 'rejected') && (
                        <Button onClick={() => setUploadModalOpen(true)} className="px-8 py-3 rounded-xl bg-emerald-600 font-black uppercase tracking-widest text-xs">
                            Upload Surat Rekomendasi
                        </Button>
                    )}

                    {/* Modal Rendered Here for this blockage state */}
                    <Modal isOpen={uploadModalOpen} onClose={() => { /* Prevent Closing if mandatory? Or allow close but stay on block screen */ setUploadModalOpen(false); }} title="Upload Surat Rekomendasi">
                        {/* Modal Content - Duplicated from UserDashboard usually, but let's inline strictly relevant parts */}
                        <div className="p-6">
                            <div className="mb-6 p-4 bg-blue-50 border border-blue-100 rounded-2xl flex items-start gap-3">
                                <div className="p-2 bg-blue-100 text-blue-600 rounded-xl shrink-0"><CheckCircle size={20} /></div>
                                <div className="space-y-1">
                                    <h5 className="font-bold text-slate-800 text-xs uppercase tracking-tight">Instruksi Upload</h5>
                                    <p className="text-[11px] text-slate-500 leading-relaxed">Pastikan surat rekomendasi asli. Format: PDF/JPG (Max 5MB).</p>
                                    {indentSubmission?.status === 'rejected' && (
                                        <div className="mt-2 p-3 bg-rose-50 border border-rose-100 rounded-xl text-rose-600 text-[10px] font-bold">
                                            <span className="block uppercase tracking-widest mb-1">Ditolak Karena:</span>
                                            {indentSubmission.rejection_reason || 'Dokumen tidak valid.'}
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className="space-y-4 mb-6">
                                <Input label="Nama Lengkap Calon Siswa" value={recStudentName} onChange={(e) => setRecStudentName(e.target.value)} placeholder="Contoh: Ahmad Abdullah" />
                                <Select label="Pilih Cabang Tujuan" value={recUnitId} onChange={(e) => setRecUnitId(e.target.value)} options={branches.map(b => ({ value: b.id, label: b.name }))} placeholder="-- Pilih Cabang --" />
                            </div>
                            <div className="relative group cursor-pointer mb-8">
                                <input type="file" id="rec-upload-wiz" className="hidden" accept="image/*,.pdf" onChange={(e) => setRecommendationFile(e.target.files[0])} />
                                <label htmlFor="rec-upload-wiz" className={`flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-2xl w-full cursor-pointer ${recommendationFile ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200 hover:border-emerald-400'}`}>
                                    {recommendationFile ? (
                                        <div className="text-center">
                                            <FileText size={32} className="mx-auto text-emerald-500 mb-2" />
                                            <p className="font-bold text-sm text-slate-800">{recommendationFile.name}</p>
                                        </div>
                                    ) : (
                                        <div className="text-center">
                                            <span className="text-sm font-bold text-slate-400">Pilih File Dokumen</span>
                                        </div>
                                    )}
                                </label>
                            </div>
                            <Button className="w-full bg-emerald-600 rounded-xl py-4 font-black uppercase tracking-widest text-xs" onClick={handleSubmitRecommendation} disabled={uploadingRec || !recommendationFile}>
                                {uploadingRec ? 'Mengirim...' : 'Kirim Dokumen'}
                            </Button>
                        </div>
                    </Modal>
                </Card>
            </div>
        );
    }

    return (
        <div className="max-w-4xl mx-auto px-1 md:px-0">
            <Card className="p-0 overflow-hidden border border-slate-200 shadow-2xl shadow-emerald-900/5 rounded-[2.5rem] bg-white dark:!bg-slate-900 relative">
                <div className="absolute top-0 left-0 w-full h-2 bg-slate-100">
                    <div
                        className="h-full bg-emerald-500 transition-all duration-700 ease-out"
                        style={{ width: `${(step / steps_list.length) * 100}%` }}
                    />
                </div>

                <div className="p-6 md:p-12">
                    <div className="mb-10 text-center md:text-left">
                        <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-50 rounded-full text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-4">
                            Step {step} of {steps_list.length}
                        </div>
                        <h2 className="text-3xl md:text-4xl font-black text-slate-800 dark:text-white tracking-tighter uppercase leading-none">
                            Formulir {isIndentMode ? `Inden ${isInternal ? 'Internal' : 'Eksternal'}` : 'Pendaftaran'}
                        </h2>
                        <div className="mt-2 mb-3 animate-slide-down">
                            <p className="text-lg md:text-xl font-bold text-slate-600 dark:text-slate-300">IDN Boarding School</p>
                            <p className="text-md font-bold text-emerald-600 dark:text-emerald-400">
                                Tahun Ajaran {academicYears.length > 0
                                    ? (isIndentMode
                                        ? (indentWaves.length > 0 ? indentWaves[0].year : academicYears.find(ay => ay.indent_enabled && !ay.is_default)?.year || 'Mendatang')
                                        : academicYears.find(ay => ay.is_default)?.year || '-')
                                    : '...'}
                            </p>
                        </div>
                        <p className="text-slate-400 text-sm mt-2 font-medium">Lengkapi seluruh data dengan benar untuk mempermudah proses seleksi.</p>
                    </div>

                    {/* Premium Step Icons */}
                    <div className="flex justify-between mb-12 relative overflow-x-auto no-scrollbar py-4 gap-4 px-2">
                        {steps_list.map((s, idx) => {
                            const Icon = s.icon;
                            const isActive = step === idx + 1;
                            const isCompleted = step > idx + 1;
                            return (
                                <div key={idx} className="flex flex-col items-center gap-2 min-w-fit first:pl-0 last:pr-0">
                                    <div
                                        onClick={() => isCompleted && setStep(idx + 1)}
                                        className={`w-12 h-12 rounded-2xl flex items-center justify-center border-4 transition-all duration-500 cursor-pointer ${isActive
                                            ? 'bg-emerald-600 border-emerald-50 text-white shadow-xl shadow-emerald-200 scale-110'
                                            : (isCompleted ? 'bg-emerald-50 border-emerald-50 text-emerald-600' : 'bg-slate-50 border-slate-50 text-slate-300')
                                            }`}
                                    >
                                        {isCompleted ? <CheckCircle size={20} /> : <Icon size={20} />}
                                    </div>
                                    <span className={`text-[9px] font-black uppercase tracking-widest ${isActive ? 'text-emerald-700' : 'text-slate-400'}`}>
                                        {s.title}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                    {step === 1 && (
                        <div className="animate-fade-in space-y-4">
                            <h3 className="text-lg font-bold text-slate-800 dark:text-white border-b pb-2 mb-4 flex items-center gap-2"><User size={20} /> A. Keterangan Pribadi</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Input label="1a. Nama Lengkap (Sesuai Akta)" value={formData.student_new.name} onChange={e => handleNestedChange('student_new', 'name', e.target.value)} required />
                                <Input label="1b. Nama Panggilan" value={formData.student_new.nickname} onChange={e => handleNestedChange('student_new', 'nickname', e.target.value)} />
                                <Select label="2. Jenis Kelamin" value={formData.student_new.gender} onChange={e => handleNestedChange('student_new', 'gender', e.target.value)} options={[{ value: 'L', label: 'Laki-laki' }, { value: 'P', label: 'Perempuan' }]} />
                                <div className="grid grid-cols-2 gap-4">
                                    <Input label="3a. Tempat Lahir" value={formData.student_new.pob} onChange={e => handleNestedChange('student_new', 'pob', e.target.value)} />
                                    <Input label="3b. Tanggal Lahir" type="date" value={formData.student_new.dob} onChange={e => handleNestedChange('student_new', 'dob', e.target.value)} />
                                </div>
                                <Select label="4. Agama" value={formData.student_new.religion} onChange={e => handleNestedChange('student_new', 'religion', e.target.value)} options={[{ value: 'Islam' }, { value: 'Kristen' }, { value: 'Katolik' }, { value: 'Hindu' }, { value: 'Buddha' }, { value: 'Konghucu' }]} />
                                <Input label="5. Kewarganegaraan" value={formData.student_new.nationality} onChange={e => handleNestedChange('student_new', 'nationality', e.target.value)} placeholder="Indonesia" />
                                <Input label="NIK (16 Digit)" value={formData.student_new.nik} onChange={e => handleNestedChange('student_new', 'nik', e.target.value)} placeholder="16 digit NIK" />
                                <Input label="Nomor KK" value={formData.student_new.kk} onChange={e => handleNestedChange('student_new', 'kk', e.target.value)} placeholder="16 digit No. KK" />
                            </div>

                            <div className="bg-gray-50 dark:!bg-slate-900 p-4 rounded-lg border border-gray-200 dark:border-slate-700 mt-4">
                                <h4 className="font-bold text-sm mb-3 text-slate-700 dark:text-slate-200">Data Keluarga</h4>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                    <Input label="6. Anak ke-" type="number" value={formData.student_new.child_order} onChange={e => handleNestedChange('student_new', 'child_order', e.target.value)} />
                                    <Input label="7. Jml Saudara Kandung" type="number" value={formData.student_new.siblings_count} onChange={e => handleNestedChange('student_new', 'siblings_count', e.target.value)} />
                                    <Input label="8. Jml Saudara Tiri" type="number" value={formData.student_new.siblings_step} onChange={e => handleNestedChange('student_new', 'siblings_step', e.target.value)} placeholder="0" />
                                    <Input label="9. Jml Saudara Angkat" type="number" value={formData.student_new.siblings_adopted} onChange={e => handleNestedChange('student_new', 'siblings_adopted', e.target.value)} placeholder="0" />
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                                    <Select label="10. Status Anak" value={formData.student_new.orphan_status} onChange={e => handleNestedChange('student_new', 'orphan_status', e.target.value)} options={[{ value: 'Lengkap', label: 'Orang Tua Lengkap' }, { value: 'Yatim', label: 'Yatim (Ayah Meninggal)' }, { value: 'Piatu', label: 'Piatu (Ibu Meninggal)' }, { value: 'Yatim Piatu', label: 'Yatim Piatu' }]} />
                                    <Input label="11. Bahasa Sehari-hari di Rumah" value={formData.student_new.daily_language} onChange={e => handleNestedChange('student_new', 'daily_language', e.target.value)} placeholder="Indonesia / Jawa / Sunda / dll" />
                                </div>
                            </div>

                            <h3 className="text-lg font-bold text-slate-800 dark:text-white border-b pb-2 mt-6 mb-4 flex items-center gap-2"><Activity size={20} /> C. Keterangan Kesehatan</h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <Input label="17. Golongan Darah" value={formData.student_new.blood_type} onChange={e => handleNestedChange('student_new', 'blood_type', e.target.value)} placeholder="A / B / AB / O" />
                                <Input label="20a. Tinggi Badan (cm)" type="number" value={formData.student_new.height} onChange={e => handleNestedChange('student_new', 'height', e.target.value)} />
                                <Input label="20b. Berat Badan (kg)" type="number" value={formData.student_new.weight} onChange={e => handleNestedChange('student_new', 'weight', e.target.value)} />
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Input label="18a. Penyakit yang Pernah Diderita" value={formData.student_new.diseases} onChange={e => handleNestedChange('student_new', 'diseases', e.target.value)} placeholder="Contoh: Asma, Tifus (Kosongkan jika tidak ada)" />
                                <Input label="18b. Tempat Dirawat" value={formData.student_new.diseases_hospital} onChange={e => handleNestedChange('student_new', 'diseases_hospital', e.target.value)} placeholder="Contoh: RS Mitra Keluarga" />
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Input label="19. Kelainan Jasmani" value={formData.student_new.physical_disability} onChange={e => handleNestedChange('student_new', 'physical_disability', e.target.value)} placeholder="Kosongkan jika tidak ada" />
                                <Input label="Alergi" value={formData.student_new.allergies} onChange={e => handleNestedChange('student_new', 'allergies', e.target.value)} placeholder="Contoh: Udang, Antibiotik" />
                            </div>
                            <Input label="Kebutuhan Khusus (ABK)" value={formData.student_new.special_needs} onChange={e => handleNestedChange('student_new', 'special_needs', e.target.value)} placeholder="Tuliskan jika ada" />
                            {renderNav(null, 2, !formData.student_new.name || !formData.student_new.nik)}
                        </div>
                    )}
                    {step === 2 && (
                        <div className="animate-fade-in space-y-4">
                            <h3 className="text-lg font-bold text-slate-800 dark:text-white border-b pb-2 mb-4 flex items-center gap-2"><School size={20} /> D. Keterangan Pendidikan Sebelumnya</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Input label="21a. Asal Sekolah (SLTP/SD/sederajat)" value={formData.education.origin_school} onChange={e => handleNestedChange('education', 'origin_school', e.target.value)} />
                                <Input label="NPSN Sekolah" value={formData.education.npsn} onChange={e => handleNestedChange('education', 'npsn', e.target.value)} />
                                <Select label="Status Sekolah" value={formData.education.school_status} onChange={e => handleNestedChange('education', 'school_status', e.target.value)} options={[{ value: 'Negeri', label: 'Negeri' }, { value: 'Swasta', label: 'Swasta' }]} />
                                <Input label="21c. Lama Belajar (Tahun)" type="number" value={formData.education.study_duration} onChange={e => handleNestedChange('education', 'study_duration', e.target.value)} placeholder="Contoh: 6" />
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <Input label="21b. Nomor STTB/Ijazah" value={formData.education.diploma_no} onChange={e => handleNestedChange('education', 'diploma_no', e.target.value)} />
                                <Input label="Tanggal STTB/Ijazah" type="date" value={formData.education.diploma_date} onChange={e => handleNestedChange('education', 'diploma_date', e.target.value)} />
                                <Input label="Tahun Lulus" type="number" value={formData.education.grad_year} onChange={e => handleNestedChange('education', 'grad_year', e.target.value)} />
                            </div>
                            <div className="bg-gray-50 dark:!bg-slate-900 p-4 rounded-lg mt-4 border border-gray-200 dark:border-slate-700">
                                <h4 className="font-bold text-sm mb-3 text-slate-700 dark:text-slate-200">Nilai Rapor Terakhir (Skala 10-100)</h4>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                    <Input label="Matematika" type="number" value={formData.education.grade_math} onChange={e => handleNestedChange('education', 'grade_math', e.target.value)} />
                                    <Input label="B. Indonesia" type="number" value={formData.education.grade_ind} onChange={e => handleNestedChange('education', 'grade_ind', e.target.value)} />
                                    <Input label="B. Inggris" type="number" value={formData.education.grade_eng} onChange={e => handleNestedChange('education', 'grade_eng', e.target.value)} />
                                    <Input label="IPA (Opsional)" type="number" value={formData.education.grade_ipa} onChange={e => handleNestedChange('education', 'grade_ipa', e.target.value)} />
                                </div>
                            </div>
                            <Input label="Prestasi Akademik / Non-Akademik" value={formData.education.achievements} onChange={e => handleNestedChange('education', 'achievements', e.target.value)} placeholder="Contoh: Juara 1 Lomba Pidato Tingkat Kota" />
                            {renderNav(1, 3, !formData.education.origin_school)}
                        </div>
                    )}
                    {step === 3 && (
                        <div className="animate-fade-in space-y-4">
                            <h3 className="text-lg font-bold text-slate-800 dark:text-white border-b pb-2 mb-4 flex items-center gap-2"><MapPin size={20} /> B. Keterangan Tempat Tinggal</h3>
                            <Input label="12. Alamat Lengkap (Jalan, RT/RW, No. Rumah)" value={formData.address.street} onChange={e => handleNestedChange('address', 'street', e.target.value)} required />
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Select label="Provinsi" value={regionIds.province} onChange={(e) => { const opt = regions.provinces.find(p => p.id === e.target.value); handleRegionChange('province', e.target.value, opt?.text); }} options={regions.provinces.map(p => ({ value: p.id, label: p.text }))} placeholder="Pilih Provinsi" />
                                <Select label="Kabupaten / Kota" value={regionIds.regency} onChange={(e) => { const opt = regions.regencies.find(p => p.id === e.target.value); handleRegionChange('regency', e.target.value, opt?.text); }} options={regions.regencies.map(p => ({ value: p.id, label: p.text }))} disabled={!regionIds.province} placeholder="Pilih Kota/Kab" />
                                <Select label="Kecamatan" value={regionIds.district} onChange={(e) => { const opt = regions.districts.find(p => p.id === e.target.value); handleRegionChange('district', e.target.value, opt?.text); }} options={regions.districts.map(p => ({ value: p.id, label: p.text }))} disabled={!regionIds.regency} placeholder="Pilih Kecamatan" />
                                <Select label="Desa / Kelurahan" value={formData.address.village} onChange={(e) => { handleRegionChange('village', null, e.target.value); }} options={regions.villages.map(p => ({ value: p.text, label: p.text }))} disabled={!regionIds.district} placeholder="Pilih Desa/Kelurahan" />
                                <Input label="Kode Pos" value={formData.address.postal_code} onChange={e => handleNestedChange('address', 'postal_code', e.target.value)} />
                                <Input label="13. Nomor Telepon Rumah" value={formData.address.phone} onChange={e => handleNestedChange('address', 'phone', e.target.value)} placeholder="Contoh: 021-7654321" />
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Select label="14. Alamat Tersebut" value={formData.address.address_status} onChange={e => handleNestedChange('address', 'address_status', e.target.value)} options={[{ value: 'Milik Sendiri', label: 'Milik Sendiri' }, { value: 'Rumah Dinas', label: 'Rumah Dinas' }, { value: 'Kontrak/Sewa', label: 'Kontrak/Sewa' }, { value: 'Menumpang', label: 'Menumpang' }, { value: 'Lainnya', label: 'Lainnya' }]} />
                                <Input label="15. Jarak ke Sekolah (km)" type="number" value={formData.address.distance} onChange={e => handleNestedChange('address', 'distance', e.target.value)} placeholder="Perkiraan KM" />
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Select label="16. Ke Sekolah Dengan" value={formData.address.transport_mode} onChange={e => handleNestedChange('address', 'transport_mode', e.target.value)} options={[{ value: 'Jalan Kaki', label: 'Jalan Kaki' }, { value: 'Sepeda', label: 'Sepeda' }, { value: 'Sepeda Motor', label: 'Sepeda Motor' }, { value: 'Mobil Pribadi', label: 'Mobil Pribadi' }, { value: 'Angkutan Umum', label: 'Angkutan Umum' }, { value: 'Antar Jemput Sekolah', label: 'Antar Jemput Sekolah' }, { value: 'Ojek Online', label: 'Ojek Online' }, { value: 'Lainnya', label: 'Lainnya' }]} />
                                <Select label="Tinggal Bersama" value={formData.address.residence_status} onChange={e => handleNestedChange('address', 'residence_status', e.target.value)} options={[{ value: 'Orang Tua', label: 'Bersama Orang Tua' }, { value: 'Wali', label: 'Bersama Wali' }, { value: 'Asrama', label: 'Asrama / Kost' }]} />
                            </div>
                            {renderNav(2, 4, !formData.address.street)}
                        </div>
                    )}
                    {step === 4 && (<div className="animate-fade-in space-y-6"><h3 className="text-lg font-bold text-slate-800 dark:text-white border-b pb-2 mb-4 flex items-center gap-2"><User size={20} /> 4. Data Orang Tua / Wali</h3><div className="border p-5 rounded-xl bg-blue-50/50 dark:!bg-slate-900 border-blue-100 dark:border-slate-700"><h4 className="font-bold text-blue-800 dark:text-blue-400 mb-4 flex items-center gap-2">👨‍🦱 Data Ayah</h4><div className="grid grid-cols-1 md:grid-cols-2 gap-4"><Input label="Nama Lengkap Ayah" value={formData.father.name} onChange={e => handleNestedChange('father', 'name', e.target.value)} required /><Input label="NIK Ayah" value={formData.father.nik} onChange={e => handleNestedChange('father', 'nik', e.target.value)} /><Input label="Pekerjaan" value={formData.father.job} onChange={e => handleNestedChange('father', 'job', e.target.value)} /><Select label="Pendidikan Terakhir" value={formData.father.education} onChange={e => handleNestedChange('father', 'education', e.target.value)} options={[{ value: 'SD', label: 'SD' }, { value: 'SMP', label: 'SMP' }, { value: 'SMA', label: 'SMA' }, { value: 'S1', label: 'S1' }, { value: 'S2', label: 'S2' }, { value: 'S3', label: 'S3' }, { value: 'Lainnya', label: 'Lainnya' }]} /><div className="md:col-span-2"><Select label="Penghasilan Ayah Per Bulan" value={formData.father.income} onChange={e => handleNestedChange('father', 'income', e.target.value)} options={incomeOptions} /></div><Input label="Nomor HP" value={formData.father.phone} onChange={e => handleNestedChange('father', 'phone', e.target.value)} /></div></div><div className="border p-5 rounded-xl bg-pink-50/50 dark:!bg-slate-900 border-pink-100 dark:border-slate-700"><h4 className="font-bold text-pink-800 dark:text-pink-400 mb-4 flex items-center gap-2">👩‍🦰 Data Ibu</h4><div className="grid grid-cols-1 md:grid-cols-2 gap-4"><Input label="Nama Lengkap Ibu" value={formData.mother.name} onChange={e => handleNestedChange('mother', 'name', e.target.value)} required /><Input label="NIK Ibu" value={formData.mother.nik} onChange={e => handleNestedChange('mother', 'nik', e.target.value)} /><Input label="Pekerjaan" value={formData.mother.job} onChange={e => handleNestedChange('mother', 'job', e.target.value)} /><Select label="Pendidikan Terakhir" value={formData.mother.education} onChange={e => handleNestedChange('mother', 'education', e.target.value)} options={[{ value: 'SD', label: 'SD' }, { value: 'SMP', label: 'SMP' }, { value: 'SMA', label: 'SMA' }, { value: 'S1', label: 'S1' }, { value: 'S2', label: 'S2' }, { value: 'S3', label: 'S3' }, { value: 'Lainnya', label: 'Lainnya' }]} /><div className="md:col-span-2"><Select label="Penghasilan Ibu Per Bulan" value={formData.mother.income} onChange={e => handleNestedChange('mother', 'income', e.target.value)} options={incomeOptions} /></div><Input label="Nomor HP" value={formData.mother.phone} onChange={e => handleNestedChange('mother', 'phone', e.target.value)} /></div></div><div className="border p-5 rounded-xl bg-gray-50 dark:!bg-slate-900 border-gray-200 dark:border-slate-700"><h4 className="font-bold text-slate-700 dark:text-slate-200 mb-4">Data Wali (Jika Ada)</h4><div className="grid grid-cols-1 md:grid-cols-3 gap-4"><Input label="Nama Wali" value={formData.guardian.name} onChange={e => handleNestedChange('guardian', 'name', e.target.value)} /><Input label="Hubungan dengan Santri" value={formData.guardian.relation} onChange={e => handleNestedChange('guardian', 'relation', e.target.value)} placeholder="Contoh: Paman, Kakek" /><Input label="Nomor HP" value={formData.guardian.phone} onChange={e => handleNestedChange('guardian', 'phone', e.target.value)} /></div></div>{renderNav(3, 5, !formData.father.name || !formData.mother.name)}</div>)}
                    {step === 5 && (
                        <div className="animate-fade-in">
                            <h3 className="text-lg font-bold text-slate-800 dark:text-white border-b pb-2 mb-6 flex items-center gap-2"><Building size={20} /> 5. Pilih Cabang Sekolah</h3>

                            {/* Indent Mode Toggle */}
                            {indentWaves.length > 0 && (
                                <div className="mb-6 bg-purple-50 border border-purple-200 p-4 rounded-xl">
                                    <label className="flex items-center gap-3 cursor-pointer select-none">
                                        <input
                                            type="checkbox"
                                            checked={isIndentMode}
                                            onChange={(e) => {
                                                setIsIndentMode(e.target.checked);
                                                handleMainChange('wave_id', ''); // Reset wave selection
                                            }}
                                            className="w-5 h-5 text-purple-600 rounded focus:ring-purple-500"
                                        />
                                        <div>
                                            <span className="font-bold text-purple-800 flex items-center gap-2">
                                                📌 Pendaftaran Indent (Tahun Depan)
                                                {isIndentMode && <span className="text-xs bg-purple-200 text-purple-700 px-2 py-0.5 rounded-full">AKTIF</span>}
                                            </span>
                                            <span className="text-xs text-purple-600 block mt-0.5">Centang untuk mendaftar di tahun ajaran mendatang (booking)</span>
                                        </div>
                                    </label>
                                </div>
                            )}

                            <div className="mb-6">
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-2">Pilih Cabang Sekolah & Kuota</label>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {branches.map(u => {
                                        // 1. Determine Target Year ID
                                        let targetYearId = null;
                                        if (isIndentMode) {
                                            if (formData.wave_id) {
                                                const w = indentWaves.find(iw => iw.id === formData.wave_id);
                                                if (w) targetYearId = academicYears.find(y => y.year === w.year)?.id;
                                            } else if (indentWaves.length > 0) {
                                                // Default to first available indent wave's year if not selected
                                                targetYearId = academicYears.find(y => y.year === indentWaves[0].year)?.id;
                                            }
                                        } else {
                                            targetYearId = academicYears.find(y => y.is_default)?.id;
                                        }

                                        // 2. Get Config for Target Year or Fallback to Root
                                        const config = (targetYearId && u.academic_configs?.[targetYearId]) || {};

                                        // 3. Resolve Majors and Quotas
                                        const activeMajors = config.majors || u.majors || [];
                                        const hasMajors = activeMajors.length > 0;

                                        // 4. Use fetched stats for filled counts (works for both Regular and Indent)
                                        const unitStats = indentStats[u.id];

                                        let totalFilled = 0;
                                        let totalQuota = 0;

                                        if (hasMajors) {
                                            totalQuota = activeMajors.reduce((acc, m) => acc + (parseInt(m.quota) || 0), 0);
                                            totalFilled = activeMajors.reduce((acc, m) => {
                                                // Use stats if available, else fallback to stored filled value
                                                const filled = unitStats?.majors?.[m.name] ?? (parseInt(m.filled) || 0);
                                                return acc + filled;
                                            }, 0);
                                        } else {
                                            totalQuota = config.quota !== undefined ? parseInt(config.quota) : (parseInt(u.quota) || 0);
                                            // Use stats if available, else fallback
                                            totalFilled = unitStats?.filled ?? (config.filled !== undefined ? parseInt(config.filled) : (parseInt(u.filled) || 0));
                                        }

                                        const remaining = totalQuota - totalFilled;
                                        const isFull = remaining <= 0;
                                        const isClosed = u.open === false;
                                        const isSMK = u.level === 'SMK';

                                        return (
                                            <div key={u.id} onClick={() => !isFull && !isClosed && handleMainChange('unit_id', u.id)} className={`border p-4 rounded-xl cursor-pointer transition-all ${formData.unit_id === u.id ? 'border-emerald-500 bg-emerald-50 ring-2 ring-emerald-200' : 'hover:border-emerald-300'} ${isFull || isClosed ? 'opacity-60 bg-slate-100 cursor-not-allowed' : 'bg-white'}`}>
                                                <div className="flex justify-between items-start">
                                                    <div>
                                                        <div className="flex items-center gap-2">
                                                            <span className="font-bold text-slate-800 dark:text-white">{u.name}</span>
                                                            <span className="text-[10px] bg-slate-200 px-1.5 py-0.5 rounded font-bold uppercase">{u.level}</span>
                                                            {isClosed && <span className="text-[10px] bg-red-100 text-red-600 px-1.5 py-0.5 rounded font-bold uppercase">TUTUP</span>}
                                                        </div>
                                                        <p className="text-xs text-slate-500 mt-1">{u.location}</p>
                                                    </div>
                                                    <div className={`text-right ${isFull || isClosed ? 'text-slate-400' : 'text-emerald-600'}`}>
                                                        <div className="text-xl font-bold">{isClosed ? 'CLOSED' : (isFull ? 'PENUH' : remaining)}</div>
                                                        <div className="text-[10px] uppercase">Sisa Kuota {isSMK && '(Total)'}</div>
                                                        {targetYearId && isIndentMode && <div className="text-[9px] text-purple-600 font-bold mt-1 bg-purple-100 px-1 rounded">INDENT</div>}
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>

                            {selectedBranch && selectedBranch.level === 'SMK' && (
                                (() => {
                                    // Resolve Target Year and Config for Selected Branch Majors
                                    let targetYearId = null;
                                    if (isIndentMode) {
                                        if (formData.wave_id) {
                                            const w = indentWaves.find(iw => iw.id === formData.wave_id);
                                            if (w) targetYearId = academicYears.find(y => y.year === w.year)?.id;
                                        } else if (indentWaves.length > 0) {
                                            targetYearId = academicYears.find(y => y.year === indentWaves[0].year)?.id;
                                        }
                                    } else {
                                        targetYearId = academicYears.find(y => y.is_default)?.id;
                                    }

                                    const config = (targetYearId && selectedBranch.academic_configs?.[targetYearId]) || {};
                                    const activeMajors = config.majors || selectedBranch.majors || [];
                                    const unitStats = indentStats[selectedBranch.id];

                                    if (activeMajors.length === 0) return null;

                                    return (
                                        <div className="mb-4 animate-fade-in bg-blue-50 p-4 rounded-lg border border-blue-100">
                                            <h4 className="font-bold text-blue-800 mb-2 flex items-center gap-2"><GraduationCap size={18} /> Pilih Jurusan {isIndentMode && <span className="text-xs bg-purple-200 text-purple-800 px-2 py-0.5 rounded-full ml-2">INDENT</span>}</h4>
                                            <Select
                                                label="Jurusan / Program Studi"
                                                name="major"
                                                value={formData.major}
                                                onChange={e => handleMainChange('major', e.target.value)}
                                                options={activeMajors.map(m => {
                                                    const quota = parseInt(m.quota) || 0;
                                                    // Use stats if available, else fallback to stored filled value
                                                    const filled = unitStats?.majors?.[m.name] ?? (parseInt(m.filled) || 0);
                                                    const left = quota - filled;
                                                    return { value: m.name, label: `${m.name} (Sisa: ${left})`, disabled: left <= 0 };
                                                })}
                                                required
                                            />
                                        </div>
                                    );
                                })()
                            )}

                            <Select label="Jalur Pendaftaran" name="path_id" value={formData.path_id} onChange={e => handleMainChange('path_id', e.target.value)} options={paths.map(p => ({ value: p.id, label: p.name }))} />

                            {/* Wave Selection based on Mode */}
                            {(() => {
                                const displayWaves = isIndentMode ? indentWaves : waves;
                                const hasWaves = displayWaves.length > 0;
                                const defaultYear = academicYears.find(ay => ay.is_default);

                                return hasWaves ? (
                                    <div className={isIndentMode ? "bg-purple-50 p-4 rounded-xl border border-purple-200" : ""}>
                                        <Select
                                            label={isIndentMode ? "📌 Tahun Ajaran / Gelombang (INDENT)" : `Tahun Ajaran / Gelombang ${defaultYear ? `(${defaultYear.year})` : ''}`}
                                            name="wave_id"
                                            value={formData.wave_id}
                                            onChange={e => handleMainChange('wave_id', e.target.value)}
                                            options={displayWaves.map(w => ({ value: w.id, label: `${w.year} - ${w.name}${isIndentMode ? ' (Indent)' : ''}` }))}
                                        />
                                        {isIndentMode && <p className="text-xs text-purple-600 mt-2 italic">⚠️ Anda mendaftar untuk tahun ajaran mendatang. Kuota akan dipesan dan pembayaran dapat dilakukan sesuai jadwal.</p>}
                                    </div>
                                ) : (
                                    <div className="text-red-500 text-sm mb-4 p-4 bg-red-50 rounded-lg border border-red-200">
                                        {isIndentMode
                                            ? 'Tidak ada pendaftaran indent yang tersedia.'
                                            : (!defaultYear
                                                ? '⚠️ Belum ada tahun akademik default. Hubungi admin untuk mengaktifkan pendaftaran.'
                                                : 'Tidak ada pendaftaran aktif untuk tahun akademik ini.')}
                                    </div>
                                );
                            })()}

                            {renderNav(4, 6, !formData.unit_id || !formData.wave_id || (selectedBranch?.level === 'SMK' && !formData.major))}
                        </div>
                    )}
                    {step === 6 && (
                        <div className="animate-fade-in">
                            <h3 className="text-lg font-bold text-slate-800 dark:text-white border-b pb-2 mb-4 flex items-center gap-2"><FileText size={20} /> 6. Upload Dokumen</h3>

                            {/* Student Photo Upload Section - Added as per request */}
                            <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-xl border border-emerald-200 dark:border-emerald-800 mb-6">
                                <h4 className="font-bold text-emerald-800 dark:text-emerald-300 mb-2 flex items-center gap-2">📸 Pas Foto Siswa (Wajib)</h4>
                                <div className="text-sm text-emerald-700 dark:text-emerald-400 mb-4 bg-white dark:bg-slate-800 p-3 rounded-lg border border-emerald-100 dark:border-emerald-900/50">
                                    <ul className="list-disc list-inside space-y-1">
                                        <li>Foto harus <strong>jelas dan tajam</strong>.</li>
                                        <li>Menggunakan <strong>pakaian putih rapi</strong> (berkerah).</li>
                                        <li>
                                            Background sesuaikan tahun kelahiran:
                                            <span className="font-bold ml-1">
                                                <span className="text-red-600 bg-red-100 px-1 rounded">Ganjil = Merah</span> /
                                                <span className="text-blue-600 bg-blue-100 px-1 rounded ml-1">Genap = Biru</span>
                                            </span>
                                        </li>
                                    </ul>
                                </div>

                                <div className="flex items-center justify-between p-4 border rounded-xl bg-white dark:bg-slate-800 hover:shadow transition-all border-emerald-200 dark:border-emerald-700">
                                    <span className="uppercase font-medium text-sm flex items-center gap-3 text-slate-700 dark:text-slate-200">
                                        <div className="p-2 bg-emerald-100 dark:bg-emerald-900 rounded-full border border-emerald-200 dark:border-emerald-700">
                                            <User size={16} className="text-emerald-600 dark:text-emerald-400" />
                                        </div>
                                        Pas Foto Siswa
                                    </span>
                                    <div className="flex items-center gap-2">
                                        {uploadingDocs.photo_student ? (
                                            <span className="text-xs text-blue-600 font-bold flex items-center gap-1">
                                                <div className="w-3 h-3 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div> Memproses...
                                            </span>
                                        ) : formData.documents.photo_student ? (
                                            <div className="flex flex-col items-end gap-1">
                                                <span className="text-emerald-600 font-bold text-xs flex items-center gap-1 bg-emerald-50 dark:bg-emerald-900/30 px-3 py-1 rounded-full border border-emerald-100 dark:border-emerald-800">
                                                    <CheckCircle size={14} /> Terupload
                                                </span>
                                                <div className="flex gap-2">
                                                    <button onClick={() => {
                                                        const dataUri = formData.documents.photo_student;
                                                        const win = window.open();
                                                        if (win) {
                                                            const img = win.document.createElement('img');
                                                            img.src = dataUri;
                                                            img.style.maxWidth = '100%';
                                                            win.document.body.appendChild(img);
                                                        }
                                                    }} className="text-[10px] text-blue-500 hover:underline">Lihat</button>
                                                    <button onClick={() => setFormData(prev => ({ ...prev, documents: { ...prev.documents, photo_student: null } }))} className="text-[10px] text-red-500 hover:underline">Hapus</button>
                                                </div>
                                            </div>
                                        ) : (
                                            <div className="relative">
                                                <input
                                                    type="file"
                                                    onChange={(e) => uploadFile('photo_student', e.target.files[0])}
                                                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                                    accept="image/*"
                                                />
                                                <Button variant="secondary" className="text-xs py-1 pointer-events-none">Upload Foto</Button>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-3 mb-6">
                                {['kk', 'akta', 'rapor', 'surat_sehat'].map((type) => (
                                    <div key={type} className="flex items-center justify-between p-4 border rounded-xl bg-gray-50 dark:!bg-slate-900 border-gray-200 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-800 hover:shadow transition-all">
                                        <span className="uppercase font-medium text-sm flex items-center gap-3"><div className="p-2 bg-white rounded-full border"><FileText size={16} className="text-slate-500" /></div>{type.replace('_', ' ')}</span>
                                        <div className="flex items-center gap-2">
                                            {uploadingDocs[type] ? (
                                                <span className="text-xs text-blue-600 font-bold flex items-center gap-1">
                                                    <div className="w-3 h-3 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div> Memproses...
                                                </span>
                                            ) : formData.documents[type] ? (
                                                <div className="flex flex-col items-end gap-1">
                                                    <span className="text-emerald-600 font-bold text-xs flex items-center gap-1 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                                                        <CheckCircle size={14} /> Terupload
                                                    </span>
                                                    <div className="flex gap-2">
                                                        <button onClick={() => {
                                                            const dataUri = formData.documents[type];
                                                            const win = window.open();
                                                            if (win) {
                                                                if (dataUri.startsWith('data:image')) {
                                                                    const img = win.document.createElement('img');
                                                                    img.src = dataUri;
                                                                    img.style.maxWidth = '100%';
                                                                    win.document.body.appendChild(img);
                                                                } else {
                                                                    const iframe = win.document.createElement('iframe');
                                                                    iframe.src = dataUri;
                                                                    iframe.style.width = '100%';
                                                                    iframe.style.height = '100%';
                                                                    iframe.style.border = 'none';
                                                                    win.document.body.appendChild(iframe);
                                                                }
                                                            }
                                                        }} className="text-[10px] text-blue-500 hover:underline">Lihat</button>
                                                        <button onClick={() => setFormData(prev => ({ ...prev, documents: { ...prev.documents, [type]: null } }))} className="text-[10px] text-red-500 hover:underline">Hapus</button>
                                                    </div>
                                                </div>
                                            ) : (
                                                <div className="relative">
                                                    <input type="file" onChange={(e) => uploadFile(type, e.target.files[0])} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="image/*,.pdf" />
                                                    <Button variant="secondary" className="text-xs py-1 pointer-events-none">Pilih File</Button>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                ))}

                                {/* SKTM Logic: Show ONLY for Yatim & Duafa paths */}
                                {(() => {
                                    const pathName = (paths.find(p => p.id === formData.path_id)?.name || '').toLowerCase();
                                    const isYatimOrDuafa = pathName.includes('yatim') || pathName.includes('duafa');
                                    return isYatimOrDuafa;
                                })() && (
                                        <div className="flex items-center justify-between p-4 border rounded-xl bg-yellow-50 hover:bg-white hover:shadow transition-all border-yellow-200">
                                            <div>
                                                <span className="uppercase font-medium text-sm flex items-center gap-3"><div className="p-2 bg-white rounded-full border"><FileText size={16} className="text-slate-500" /></div>Surat Keterangan Tidak Mampu (SKTM)</span>
                                                <p className="text-[10px] text-slate-500 ml-11 mt-1">Wajib upload SKTM dari Kelurahan/Desa untuk jalur Yatim/Duafa</p>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                {uploadingDocs['sktm'] ? (
                                                    <span className="text-xs text-blue-600 font-bold flex items-center gap-1">
                                                        <div className="w-3 h-3 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div> Memproses...
                                                    </span>
                                                ) : formData.documents['sktm'] ? (
                                                    <div className="flex flex-col items-end gap-1">
                                                        <span className="text-emerald-600 font-bold text-xs flex items-center gap-1 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                                                            <CheckCircle size={14} /> Terupload
                                                        </span>
                                                        <div className="flex gap-2">
                                                            <button onClick={() => {
                                                                const dataUri = formData.documents['sktm'];
                                                                const win = window.open();
                                                                if (win) {
                                                                    if (dataUri.startsWith('data:image')) {
                                                                        const img = win.document.createElement('img');
                                                                        img.src = dataUri;
                                                                        img.style.maxWidth = '100%';
                                                                        win.document.body.appendChild(img);
                                                                    } else {
                                                                        const iframe = win.document.createElement('iframe');
                                                                        iframe.src = dataUri;
                                                                        iframe.style.width = '100%';
                                                                        iframe.style.height = '100%';
                                                                        iframe.style.border = 'none';
                                                                        win.document.body.appendChild(iframe);
                                                                    }
                                                                }
                                                            }} className="text-[10px] text-blue-500 hover:underline">Lihat</button>
                                                            <button onClick={() => setFormData(prev => ({ ...prev, documents: { ...prev.documents, sktm: null } }))} className="text-[10px] text-red-500 hover:underline">Hapus</button>
                                                        </div>
                                                    </div>
                                                ) : (
                                                    <div className="relative">
                                                        <input
                                                            type="file"
                                                            onChange={(e) => uploadFile('sktm', e.target.files[0])}
                                                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                                            accept="image/*,.pdf"
                                                        />
                                                        <Button variant="secondary" className="text-xs py-1 pointer-events-none">Pilih File</Button>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    )}

                                {/* Rekomendasi Desa Logic: Show ONLY for Prestasi path */}
                                {(() => {
                                    const pathName = (paths.find(p => p.id === formData.path_id)?.name || '').toLowerCase();
                                    const isPrestasi = pathName.includes('prestasi');
                                    return isPrestasi;
                                })() && (
                                        <div className="flex items-center justify-between p-4 border rounded-xl bg-purple-50 hover:bg-white hover:shadow transition-all border-purple-200">
                                            <div>
                                                <span className="uppercase font-medium text-sm flex items-center gap-3"><div className="p-2 bg-white rounded-full border"><FileText size={16} className="text-slate-500" /></div>Surat Rekomendasi Desa/Kelurahan</span>
                                                <p className="text-[10px] text-slate-500 ml-11 mt-1">Wajib upload Surat Rekomendasi dari Desa/Kelurahan untuk jalur Prestasi</p>
                                            </div>
                                            <div className="flex items-center gap-2">{uploadingDocs['rekomendasi_desa'] ? (<span className="text-xs text-blue-600 font-bold flex items-center gap-1"><div className="w-3 h-3 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div> Memproses...</span>) : formData.documents['rekomendasi_desa'] ? (<div className="flex flex-col items-end"><span className="text-emerald-600 font-bold text-xs flex items-center gap-1 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100"><CheckCircle size={14} /> Terupload (Lokal)</span><button onClick={() => {
                                                const dataUri = formData.documents['rekomendasi_desa'];
                                                const win = window.open();
                                                if (win) {
                                                    if (dataUri.startsWith('data:image')) {
                                                        const img = win.document.createElement('img');
                                                        img.src = dataUri;
                                                        img.style.maxWidth = '100%';
                                                        win.document.body.appendChild(img);
                                                    } else {
                                                        const iframe = win.document.createElement('iframe');
                                                        iframe.src = dataUri;
                                                        iframe.style.width = '100%';
                                                        iframe.style.height = '100%';
                                                        iframe.style.border = 'none';
                                                        win.document.body.appendChild(iframe);
                                                    }
                                                }
                                            }} className="text-[10px] text-blue-500 hover:underline mt-1">Lihat File</button></div>) : (<div className="relative"><input type="file" onChange={(e) => uploadFile('rekomendasi_desa', e.target.files[0])} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="image/*,.pdf" /><Button variant="secondary" className="text-xs py-1 pointer-events-none">Pilih File</Button></div>)}</div>
                                        </div>
                                    )}
                            </div>
                            {renderNav(5, 7, !formData.documents.kk || !formData.documents.surat_sehat || !formData.documents.photo_student || ((() => {
                                const pathName = (paths.find(p => p.id === formData.path_id)?.name || '').toLowerCase();
                                if ((pathName.includes('yatim') || pathName.includes('duafa')) && !formData.documents.sktm) return true;
                                if (pathName.includes('prestasi') && !formData.documents.rekomendasi_desa) return true;
                                return false;
                            })()))}
                        </div>
                    )}
                    {step === 7 && (
                        <div className="animate-fade-in">
                            <div className="bg-emerald-50 p-6 rounded-xl border border-emerald-100 mb-6">
                                <h3 className="font-bold text-emerald-800 text-lg mb-2 flex items-center gap-2"><CheckSquare size={20} /> 7. Konfirmasi Akhir</h3>
                                {(() => {
                                    const pName = paths.find(p => p.id === formData.path_id)?.name || '';
                                    const isScholarship = pName.toLowerCase().includes('prestasi') || pName.toLowerCase().includes('yatim');

                                    return (
                                        <div className="text-left bg-white p-5 rounded-lg border text-sm space-y-3 mb-4 shadow-sm">
                                            <div className="flex justify-between border-b pb-2"><span className="text-slate-500">Nama Siswa</span> <strong className="text-slate-800 dark:text-white">{formData.student_new.name}</strong></div>
                                            <div className="flex justify-between border-b pb-2"><span className="text-slate-500">Cabang Sekolah</span> <strong className="text-slate-800 dark:text-white">{selectedBranch?.name}</strong></div>
                                            {formData.major && <div className="flex justify-between border-b pb-2"><span className="text-slate-500">Jurusan</span> <strong className="text-slate-800 dark:text-white">{formData.major}</strong></div>}
                                            <div className="flex justify-between border-b pb-2"><span className="text-slate-500">Gelombang</span> <strong className="text-slate-800 dark:text-white">{waves.find(w => w.id === formData.wave_id)?.name}</strong></div>
                                            <div className="flex justify-between border-b pb-2"><span className="text-slate-500">Jalur Pendaftaran</span> <strong className="text-slate-800 dark:text-white">{pName}</strong></div>
                                            <div className="flex justify-between"><span>Nama Ayah:</span> <strong>{formData.father.name}</strong></div>
                                            <div className="flex justify-between border-t pt-2 mt-2 font-bold text-emerald-700">
                                                <span>Total Biaya Pendaftaran:</span>
                                                {(() => {
                                                    const unitFee = selectedBranch?.cost_reg !== undefined ? selectedBranch.cost_reg : 0;
                                                    return <span>{isScholarship ? 'GRATIS (Beasiswa)' : `Rp ${unitFee.toLocaleString()}`}</span>;
                                                })()}
                                            </div>
                                        </div>
                                    );
                                })()}
                                <div className="flex items-start gap-3 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                                    <input type="checkbox" id="healthCheck" checked={formData.agreed_health} onChange={e => handleMainChange('agreed_health', e.target.checked)} className="mt-1 w-5 h-5 text-emerald-600 rounded focus:ring-emerald-500" />
                                    <label htmlFor="healthCheck" className="text-sm text-yellow-800 leading-snug cursor-pointer select-none">Dengan ini saya menyatakan bahwa seluruh data yang saya isi (Data Diri, Pendidikan, Orang Tua, dan Dokumen) adalah benar dan dapat dipertanggungjawabkan. Saya menyatakan <strong>anak saya sehat jasmani dan rohani</strong>.</label>
                                </div>
                            </div>
                            {renderNav(6, null, !formData.agreed_health)}
                        </div>
                    )}
                </div>
            </Card >
        </div >
    );
}
