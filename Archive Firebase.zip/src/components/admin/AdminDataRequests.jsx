import React, { useState, useEffect } from 'react';
import {
    collection, query, where, onSnapshot, doc, updateDoc,
    getDoc
} from 'firebase/firestore';
import {
    FileEdit, CheckCircle, XCircle
} from 'lucide-react';
import { db, appId } from '../../config/firebase';
import { Card, Button } from '../ui/Elements';

export default function AdminDataRequests({ showToast }) {
    const [requests, setRequests] = useState([]);

    useEffect(() => {
        const q = query(collection(db, 'artifacts', appId, 'public', 'data', 'edit_requests'), where('status', '==', 'pending'));
        const unsub = onSnapshot(q, (snap) => setRequests(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
        return () => unsub();
    }, []);

    const handleAction = async (req, action) => {
        try {
            // Update request status
            await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'edit_requests', req.id), { status: action });
            // Update student edit_request status
            await updateDoc(doc(db, 'artifacts', appId, 'users', req.user_id, 'students', req.student_id), { 'edit_request.status': action });
            showToast(`Permintaan ${action === 'approved' ? 'disetujui' : 'ditolak'}`);
        } catch (e) { showToast(e.message, 'error'); }
    };

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold flex items-center gap-2 text-slate-800"><FileEdit className="text-emerald-600" /> Permintaan Perubahan Data</h2>
            <div className="space-y-4">
                {requests.length === 0 ? <div className="text-center p-10 text-slate-400 border border-dashed rounded-xl">Tidak ada permintaan edit data baru.</div> : (
                    requests.map(req => (
                        <Card key={req.id} className="p-4">
                            <div className="flex justify-between items-start mb-2">
                                <div>
                                    <h4 className="font-bold text-slate-800">{req.student_name}</h4>
                                    <p className="text-xs text-slate-500">Wali: {req.parent_name}</p>
                                </div>
                                <div className="text-xs bg-slate-100 px-2 py-1 rounded text-slate-500">{new Date(req.requested_at).toLocaleDateString()}</div>
                            </div>
                            <div className="bg-amber-50 p-3 rounded text-sm text-amber-900 border border-amber-100 mb-4">
                                <strong>Alasan:</strong> {req.reason}
                            </div>
                            <div className="flex gap-2 justify-end">
                                <Button variant="danger" onClick={() => handleAction(req, 'rejected')} className="px-3 text-xs"><XCircle className="mr-1" size={14} /> Tolak</Button>
                                <Button onClick={() => handleAction(req, 'approved')} className="px-3 text-xs"><CheckCircle className="mr-1" size={14} /> Izinkan Edit</Button>
                            </div>
                        </Card>
                    ))
                )}
            </div>
        </div>
    );
}
