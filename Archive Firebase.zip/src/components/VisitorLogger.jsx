import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { doc, getDoc, addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db, appId } from '../config/firebase';

const VisitorLogger = () => {
    const location = useLocation();
    const [isBlocked, setIsBlocked] = useState(false);
    const [blockedIp, setBlockedIp] = useState('');

    useEffect(() => {
        const logVisit = async () => {
            // Avoid logging in dev environment if needed, or just let it fly
            if (import.meta.env.MODE === 'development' && !window.location.href.includes('localhost')) {
                // maybe skip? No, user wants to see it working.
            }

            try {
                // 1. Get IP (Cache in Session to avoid spamming API)
                let ip = sessionStorage.getItem('visitor_ip');
                if (!ip) {
                    try {
                        const res = await fetch('https://api.ipify.org?format=json');
                        const data = await res.json();
                        ip = data.ip;
                        sessionStorage.setItem('visitor_ip', ip);
                    } catch (e) {
                        console.warn('Failed to get IP', e);
                        ip = 'Unknown';
                    }
                }

                // 2. Check Block
                if (ip && ip !== 'Unknown') {
                    const blockDoc = await getDoc(doc(db, 'artifacts', appId, 'public', 'security', 'blocked_ips', ip));
                    if (blockDoc.exists()) {
                        setBlockedIp(ip);
                        setIsBlocked(true);
                        return;
                    }
                }

                // 3. Log Visit
                await addDoc(collection(db, 'artifacts', appId, 'visitor_logs'), {
                    ip_address: ip,
                    path: location.pathname,
                    timestamp: serverTimestamp(),
                    userAgent: navigator.userAgent,
                    referrer: document.referrer || ''
                });

            } catch (error) {
                console.error("Visitor Log Error:", error);
            }
        };

        logVisit();
    }, [location]);

    if (isBlocked) {
        return (
            <div style={{
                position: 'fixed',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                zIndex: 9999,
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#0f172a',
                color: 'white',
                fontFamily: 'sans-serif',
                textAlign: 'center'
            }}>
                <div>
                    <h1 style={{ fontSize: '3rem', marginBottom: '1rem', color: '#ef4444' }}>Access Denied</h1>
                    <p>Your IP address ({blockedIp}) has been blocked by the administrator.</p>
                    <p style={{ marginTop: '20px', fontSize: '0.8rem', opacity: 0.5 }}>Security System</p>
                </div>
            </div>
        );
    }

    return null;
};

export default VisitorLogger;
