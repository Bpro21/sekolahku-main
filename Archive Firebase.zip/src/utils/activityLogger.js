import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db, appId } from '../config/firebase';

export const logActivity = async (user, action, description, metadata = {}) => {
    try {
        if (!user) return;

        // Fetch IP Address
        let ipAddress = 'Unknown';
        try {
            const response = await fetch('https://api.ipify.org?format=json');
            const data = await response.json();
            ipAddress = data.ip;
        } catch (e) {
            console.warn("Failed to fetch IP:", e);
        }

        await addDoc(collection(db, 'artifacts', appId, 'system_logs'), {
            timestamp: serverTimestamp(),
            user_email: user.email,
            user_name: user.displayName || 'Unknown',
            user_uid: user.uid,
            action: action, // e.g., 'UPDATE', 'CREATE', 'DELETE', 'LOGIN'
            description: description, // Human readable details
            metadata: metadata, // Object containing changed fields, IDs, etc.
            ip_address: ipAddress,
            userAgent: navigator.userAgent
        });
    } catch (error) {
        console.error("Failed to write activity log:", error);
    }
};
