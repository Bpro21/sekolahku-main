import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
    apiKey: "AIzaSyBxsm35lIx-fJV-3ydlyiy1qrfPgiQWWOM",
    authDomain: "psb-sekolah-saya.firebaseapp.com",
    projectId: "psb-sekolah-saya",
    storageBucket: "psb-sekolah-saya.firebasestorage.app",
    messagingSenderId: "927442795124",
    appId: "1:927442795124:web:8be9f00e2b867689766f21"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
// eslint-disable-next-line no-undef
export const appId = (typeof __app_id !== 'undefined') ? __app_id : 'psb-sekolah-saya';
